package pnw.ginicast;

import neuralNetwork.NNService;

public class PipelineResult {

    private NNService.Result nnResult;
    // ---- FIX: Add this constructor ----
    public PipelineResult(double[][] train, double[][] test, double[] predictions) {
        this.nnResult = new NNService.Result(train, test, predictions);
    }
    // ---- no-arg constructor ----
    public PipelineResult() {}

    public PipelineResult(double[] predictions, double[][] testArray, double[][] trainArray, double accuracy, double mse, double rmse) {
    }

    public void setTrainingResult(NNService.Result r) {
        this.nnResult = r;
    }

    public NNService.Result getTrainingResult() {
        return nnResult;
    }

    // ======= Raw Values (Already in your file) =======
    public double getAccuracy() {
        return nnResult != null ? nnResult.getAccuracy() : 0.0;
    }

    public double getMSE() {
        return nnResult != null ? nnResult.getMSE() : 0.0;
    }

    public double getRMSE() {
        return nnResult != null ? nnResult.getRMSE() : 0.0;
    }

    public double[] getPredictions() {
        return nnResult != null ? nnResult.getPredictions() : new double[0];
    }

    public double[][] getTrainSet() {
        return nnResult != null ? nnResult.train : new double[0][];
    }

    public double[][] getTestSet() {
        return nnResult != null ? nnResult.test : new double[0][];
    }


    // ===============================================================
    //              STEP 2C — USER-FRIENDLY FORMATTED VALUES
    // ===============================================================

    /** return accuracy formatted: e.g., "92.45%" */
    public String getAccuracyFormatted() {
        if (nnResult == null) return "0%";
        return String.format("%.2f%%", getAccuracy() * 100);
    }

    /** return MSE formatted: e.g., "0.00234" */
    public String getMseFormatted() {
        if (nnResult == null) return "0.0000";
        return String.format("%.4f", getMSE());
    }

    /** return RMSE formatted: e.g., "0.0481" */
    public String getRmseFormatted() {
        if (nnResult == null) return "0.0000";
        return String.format("%.4f", getRMSE());
    }


    // ===============================================================
    //            STEP 2C — SAFETY CHECKS FOR EMPTY OR FAILED RUNS
    // ===============================================================

    /** true if NNResult is missing */
    public boolean isEmpty() {
        return nnResult == null;
    }

    /** true if no predictions were produced */
    public boolean hasPredictions() {
        return nnResult != null &&
                nnResult.getPredictions() != null &&
                nnResult.getPredictions().length > 0;
    }

    /** true if training or testing sets are missing */
    public boolean isDatasetValid() {
        return nnResult != null &&
                nnResult.train != null && nnResult.train.length > 0 &&
                nnResult.test != null && nnResult.test.length > 0;
    }
}
