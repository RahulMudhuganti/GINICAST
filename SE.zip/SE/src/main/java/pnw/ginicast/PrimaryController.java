package pnw.ginicast;


import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.SnapshotParameters;
import javafx.scene.image.WritableImage;
import java.util.List;
import javax.imageio.ImageIO;

import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import java.io.PrintWriter;
import javafx.concurrent.Task;
import javafx.scene.control.Slider;
import javafx.scene.control.Label;
import javafx.stage.Window;
import java.util.ArrayList;
import neuralNetwork.NeuralNetwork;
import neuralNetwork.TestingTrainingSet;
import normalizingCSV.*;
import java.util.Arrays;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.io.FileInputStream;
import java.io.ObjectInputStream;


public class PrimaryController {
    private static List<double[]> pendingTrainData = null;
    private static List<double[]> pendingTestData = null;
    private static int pendingInputSize = 0;
    private static double pendingLearningRate = 0.0;
    public static double[][] NORMALIZED_DATA = null;
    private NeuralNetwork trainedNetwork;
    public static PipelineResult latestPipelineResult = new PipelineResult();
    // ==== GLOBAL pipeline variables (shared between Task and UI) ====
    private double[][] trainSet;
    private double[][] testSet;
    private double[] predictions;
    int inputSizeGlobal;
    private double[] predictionsGlobal;
    private String selectedModel = "default";
    double learningRateGlobal = 0.001;
    List<double[]> trainSetGlobal;
    List<double[]> testSetGlobal;
    private double trainSplitValue = 0.7; // default 70%


    // ------------------------ Shared state across scenes ------------------------
    /**
     * Persist the selected file across scenes (simple approach for one-class controller).
     */
    private static File SELECTED_FILE;

    // ------------------------ FXML references (present only where applicable) ------------------------
    @FXML
    private VBox root;                         // root in all scenes (fx:id="root")

    // Scene 1 (primary.fxml)
    @FXML
    private Label fileLabel;

    // Scene 2 (training.fxml)
    @FXML
    private TextField nodesField;
    @FXML
    private TextField lrField;
    @FXML
    private Slider splitSlider;
    @FXML
    private Label trainPctLabel;
    @FXML
    private Label testPctLabel;

    // Scene 3 (normalizing.fxml) - NEW
    @FXML
    private ProgressBar normalizingProgress;
    @FXML
    private Label normalizingStatusLabel;
    @FXML
    private Label normalizingPercentLabel; // ADD THIS FOR THE PERCENTAGE DISPLAY

    // Scene 4 (trainingprocess.fxml)
    @FXML
    private Label epochValueLabel;
    @FXML
    private ProgressBar trainingProgress;

    // Scene 5 (trainingcompleted.fxml)
    @FXML
    private Label totalEpochsLabel;

    // Scene 6 (starttesting.fxml)
    @FXML
    private ComboBox<String> modelSelector;
    @FXML
    private Label selectedModelLabel;

    // Scene 7 (testingprocess.fxml)
    @FXML
    private ProgressBar testingProgress;
    @FXML
    private Label testProgressLabel;

    // Scene 8 (testingresults.fxml)
    @FXML
    private Label accuracyLabel;
    @FXML
    private Label mseLabel;
    @FXML
    private Label rmseLabel;
    @FXML
    private VBox resultsGraphBox;
    @FXML
    private Slider trainingSplitSlider;
    @FXML
    private Button startBtn;

    // ------------------------ Helpers ------------------------
    private Timeline trainingTimeline;               // used on trainingprocess scene
    private Timeline testingTimeline;                // used on testingprocess scene
    private Timeline normalizingTimeline;            // used on normalizing scene - NEW
    private final DecimalFormat pctFmt = new DecimalFormat("0");

    private void stopAllTimelines() {
        if (trainingTimeline != null) {
            trainingTimeline.stop();
            trainingTimeline = null;
        }
        if (testingTimeline != null) {
            testingTimeline.stop();
            testingTimeline = null;
        }
    }
    // ------------------------ Initialize (runs on every scene load) ------------------------
    @FXML
    private void initialize() {
        // Keep caret/focus "nowhere" on open
        if (root != null) {
            Platform.runLater(root::requestFocus);
        }

        // Training scene wiring
        if (splitSlider != null) {
            updateSplitLabels(splitSlider.getValue());
            splitSlider.valueProperty().addListener((obs, o, n) -> updateSplitLabels(n.doubleValue()));
        }
        if (nodesField != null) setupClearOnFirstClick(nodesField, "64");
        if (lrField != null) setupClearOnFirstClick(lrField, "0.001");

        // If we're back on primary, reflect selected file
        if (fileLabel != null) {
            fileLabel.setText(SELECTED_FILE != null ? SELECTED_FILE.getName() : "no file");
        }

        // If we're on the normalizing scene, start the normalization process - NEW
        if (normalizingProgress != null) {
            startRealNormalization();
            // REAL preprocessing
        }


        if (trainingProgress != null && epochValueLabel != null) {
            System.out.println("✅ Training UI elements detected in initialize()");

            // ✅ Check if there's pending data in static variables
            if (pendingTrainData != null && !pendingTrainData.isEmpty()) {
                System.out.println("✅ Found pending data! Starting training...");

                // Copy to instance variables
                trainSetGlobal = pendingTrainData;
                testSetGlobal = pendingTestData;
                inputSizeGlobal = pendingInputSize;
                learningRateGlobal = pendingLearningRate;

                // Clear static variables
                pendingTrainData = null;
                pendingTestData = null;

                Platform.runLater(() -> {
                    double[][] trainData = convertToDoubleArray(trainSetGlobal);
                    double[][] testData = convertToDoubleArray(testSetGlobal);  // ✅ NEW
                    startRealTraining(trainData, testData, inputSizeGlobal, learningRateGlobal);  // ✅ UPDATED
                });
            } else {
                System.out.println("⚠️ No pending data in initialize()");
            }
        }


        // If we're on the testing scene, set up model selector
        if (modelSelector != null) {
            populateModelSelector();
            setupModelSelectionHandlers();
        }

        // If we're on the testing process scene, hook Esc + start 3s demo
        if (testingProgress != null || testProgressLabel != null) {
            setupTestingEscToExit();
            startDemoTesting();   // 3-second demo testing
        }
        // If we're on the testing results scene, set up demo results
        if (accuracyLabel != null || mseLabel != null || rmseLabel != null) {
            setupDemoResults();
        }

    }


    // ------------------------ Scene 1: primary.fxml ------------------------
    @FXML
    private void handleImportClick(MouseEvent event) {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Select Economic Data (CSV)");
        chooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("CSV Files (*.csv)", "*.csv")
        );

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        File chosen = chooser.showOpenDialog(stage);

        if (chosen != null) {
            SELECTED_FILE = chosen;
            if (fileLabel != null) fileLabel.setText(chosen.getName());
            System.out.println("Selected file: " + chosen.getAbsolutePath());
        } else {
            if (fileLabel != null) fileLabel.setText("no file");
        }
    }

    /**
     * Second VBox on primary → Training scene
     */
    @FXML
    private void goToScene3(MouseEvent event) {
        switchTo(event, "training.fxml", "GINICAST - Training");
    }

    // ------------------------ Scene 2: training.fxml ------------------------

    /**
     * Back button on training → primary
     */
    @FXML
    private void goToPrimary(MouseEvent event) {
        switchTo(event, "primary.fxml", "GINICAST");
    }

    /**
     * Start Training button on training scene:
     * - Only proceed if a CSV was selected on primary;
     * - Otherwise show an error alert.
     */
    @FXML
    private void handleStartTraining(ActionEvent event) {
        if (SELECTED_FILE == null) {
            showError("No CSV Selected", "Please import a CSV file before starting training.");
            return;
        }

        // Read the slider value
        trainSplitValue = splitSlider.getValue() / 100.0;

        int nodes = parseIntOrDefault(nodesField, 64);
        double lr = parseDoubleOrDefault(lrField, 0.001);

        System.out.printf("Starting training with file=%s, nodes=%d, lr=%f, split=%.2f%n",
                SELECTED_FILE.getAbsolutePath(), nodes, lr, trainSplitValue);

        // Navigate to normalizing scene
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("normalizing.fxml"));
            Parent view = loader.load();

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(view));
            stage.setTitle("GINICAST - Normalizing Data");
            stage.show();

            Platform.runLater(view::requestFocus);

            // Start the normalization process in background
//            startNormalizationProcess();
              startRealNormalization();
        } catch (IOException ioEx) {
            ioEx.printStackTrace();
            showError("Unable to open Normalizing Scene",
                    "An unexpected error occurred while loading the view.");
        }
    }
    /**
     * Auto-start training when coming from full pipeline
     */
    /**
     * Auto-start training when coming from full pipeline
     */
    /**
     * Auto-start training when coming from full pipeline
     */
    public void startActualTraining() {
        System.out.println("🚀 Auto-starting training from full pipeline...");

        // Verify data is available
        if (trainSetGlobal == null || trainSetGlobal.isEmpty()) {
            System.err.println("❌ Cannot start training - no training data!");
            showError("Training Error", "No training data available.");
            return;
        }

        if (inputSizeGlobal <= 0) {
            System.err.println("❌ Cannot start training - invalid input size!");
            showError("Training Error", "Invalid input size.");
            return;
        }

        System.out.println("✅ Starting training with:");
        System.out.println("   Training samples: " + trainSetGlobal.size());
        System.out.println("   Input size: " + inputSizeGlobal);
        System.out.println("   Learning rate: " + learningRateGlobal);

        // Just navigate to trainingprocess.fxml - it should auto-start
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("trainingprocess.fxml"));
            Parent view = loader.load();

            PrimaryController processController = loader.getController();

            // Transfer data to training process controller
            processController.trainSetGlobal = this.trainSetGlobal;
            processController.testSetGlobal = this.testSetGlobal;
            processController.inputSizeGlobal = this.inputSizeGlobal;
            processController.learningRateGlobal = this.learningRateGlobal;

            // Also set the array versions if they exist
            if (this.trainSetGlobal != null) {
                processController.trainSet = this.trainSetGlobal.toArray(new double[0][]);
            }
            if (this.testSetGlobal != null) {
                processController.testSet = this.testSetGlobal.toArray(new double[0][]);
            }

            System.out.println("✅ Data transferred to training process controller");

            // Get current stage
            Stage stage = null;
            if (root != null && root.getScene() != null) {
                stage = (Stage) root.getScene().getWindow();
            } else {
                stage = (Stage) Stage.getWindows().stream()
                        .filter(Window::isShowing)
                        .findFirst()
                        .orElse(null);
            }

            if (stage == null) {
                showError("Navigation Error", "Cannot find application window");
                return;
            }

            stage.setScene(new Scene(view));
            stage.setTitle("GINICAST - Training Process");
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
            showError("Navigation Error", "Cannot start training process: " + e.getMessage());
        }
    }

    // ------------------------ Scene 3: normalizing.fxml ------------------------

    /**
     * Start normalization process with loading bar - NEW
     */
    private void startRealNormalization() {
        if (normalizingProgress == null) {
            System.out.println("normalizingProgress is null!");
            return;
        }
        Task<Void> task = new Task<>() {

            @Override
            protected Void call() throws Exception {

                updateMessage("Reading CSV...");

                CSVReader reader =
                        new CSVReader(SELECTED_FILE.getAbsolutePath());

                if (!reader.checkFile())
                    throw new Exception("CSV file invalid or empty.");

                List<String[]> rows = reader.getRows();
                int numRows = reader.getNumberRows();
                int numCols = reader.getNumberColumns();
                String[] header = reader.getHeader();

                String[] types = new String[numCols];
                for (int i = 0; i < numCols; i++) types[i] = "double";

                updateMessage("Removing incomplete rows...");
                RemoveRows rr = new RemoveRows(rows, numRows, numCols);
                if (rr.isEmpty()) throw new Exception("All rows removed.");
                rows = rr.getRows();

                updateMessage("Removing outliers...");
                Outliers out = new Outliers(rows, types, rows.size());
                if (out.isEmpty()) throw new Exception("All rows removed in outliers.");
                rows = out.getRows();

                updateMessage("Cleaning missing values...");
                Cleaning clean =
                        new Cleaning(rows, header, types, 3);
                rows = clean.getRows();

                updateMessage("Normalizing to 0–1 range...");
                Normalizer norm =
                        new Normalizer(rows, types);

                NORMALIZED_DATA = norm.getRows();

                if (NORMALIZED_DATA.length == 0)
                    throw new Exception("Normalization produced empty dataset.");

                return null;
            }


            @Override
            protected void succeeded() {
                super.succeeded();

                try {
                    System.out.println("Normalization complete: " + NORMALIZED_DATA.length + " rows");

                    inputSizeGlobal = NORMALIZED_DATA[0].length - 1;

                    int trainCount = (int) (NORMALIZED_DATA.length * trainSplitValue);
                    int testCount = NORMALIZED_DATA.length - trainCount;

                    // FIX #2: Guard against invalid split
                    if (trainCount <= 0 || testCount <= 0) {
                        throw new Exception("Invalid train/test split. Train=" + trainCount + " Test=" + testCount);
                    }

                    // FIX #3: Debug prints
                    System.out.println("trainSplitValue = " + trainSplitValue);
                    System.out.println("Train count = " + trainCount);
                    System.out.println("Test count  = " + testCount);

                    // ✅ CORRECT WAY - Add items to ArrayList instead of arraycopy
                    trainSetGlobal = new ArrayList<>();
                    testSetGlobal = new ArrayList<>();

                    // Add training data
                    for (int i = 0; i < trainCount; i++) {
                        trainSetGlobal.add(NORMALIZED_DATA[i]);
                    }

                    // Add testing data
                    for (int i = trainCount; i < NORMALIZED_DATA.length; i++) {
                        testSetGlobal.add(NORMALIZED_DATA[i]);
                    }

                    System.out.println("✅ Train set size: " + trainSetGlobal.size());
                    System.out.println("✅ Test set size: " + testSetGlobal.size());

// ✅ STORE IN STATIC PENDING VARIABLES for training screen to pick up
                    pendingTrainData = new ArrayList<>(trainSetGlobal);
                    pendingTestData = new ArrayList<>(testSetGlobal);
                    pendingInputSize = inputSizeGlobal;
                    pendingLearningRate = learningRateGlobal;

                    System.out.println("✅ Data stored in static pending variables");

                    Platform.runLater(() -> goToTrainingProcessScene());

                } catch (Exception e) {
                    e.printStackTrace();
                    showError("Normalization Error", e.getMessage());
                }
            }

            @Override
            protected void failed() {
                showError("Normalization Failed", getException().getMessage());
            }
        };

        // UI BINDINGS
        normalizingProgress.progressProperty().bind(task.progressProperty());
        normalizingStatusLabel.textProperty().bind(task.messageProperty());
        normalizingPercentLabel.textProperty().bind(
                task.progressProperty().multiply(100).asString("%.0f%%")
        );

        Thread th = new Thread(task);
        th.setDaemon(true);
        th.start();
    }

    // ------------------------ Scene 4: trainingprocess.fxml ------------------------

    /**
     * ESC → confirm exit; Yes→ primary, No→ stay (resume).
     */
    private void setupEscToExit() {
        if (root == null) return;

        root.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if (e.getCode() == KeyCode.ESCAPE) {
                e.consume();
                if (trainingTimeline != null) trainingTimeline.pause();

                // Defer dialog so it does not run during animation/layout pulse
                Platform.runLater(() -> {
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("Confirm Exit");
                    alert.setHeaderText("Are you sure you wish to exit?");
                    alert.setContentText("Progress will be stopped and you will return to the main screen.");
                    alert.getButtonTypes().setAll(ButtonType.YES, ButtonType.NO);
                    if (root.getScene() != null) {
                        alert.initOwner(root.getScene().getWindow());
                    }
                    alert.setResizable(false);

                    Optional<ButtonType> result = alert.showAndWait();
                    if (result.isPresent() && result.get() == ButtonType.YES) {
                        if (trainingTimeline != null) trainingTimeline.stop();
                        switchToNode(root, "primary.fxml", "GINICAST");
                    } else {
                        if (trainingTimeline != null) trainingTimeline.play();
                    }
                });
            }
        });
    }
    // Method to be called after FXML is loaded and elements are injected
    public void startTrainingWhenReady(List<double[]> trainData, List<double[]> testData,
                                       int inputSize, double lr) {
        this.trainSetGlobal = trainData;
        this.testSetGlobal = testData;
        this.inputSizeGlobal = inputSize;
        this.learningRateGlobal = lr;

        System.out.println("✅ startTrainingWhenReady called with " + trainData.size() + " samples");

        // UI elements should be ready now since initialize() has run
        if (trainingProgress != null && epochValueLabel != null) {
            System.out.println("✅ UI elements available, starting training!");
            double[][] trainArray = convertToDoubleArray(trainSetGlobal);
            double[][] testArray = convertToDoubleArray(testSetGlobal);  // ✅ NEW
            startRealTraining(trainArray, testArray, inputSizeGlobal, learningRateGlobal);  // ✅ UPDATED
        } else {
            System.out.println("⚠️ UI elements still null in startTrainingWhenReady");
        }
    }

    private double[][] convertToDoubleArray(List<double[]> data) {
        if (data == null || data.isEmpty()) {
            return new double[0][0];
        }

        double[][] result = new double[data.size()][];
        for (int i = 0; i < data.size(); i++) {
            result[i] = data.get(i);
        }
        return result;
    }

    /**
     * 5-second demo: fill progress smoothly and update epoch once per second, then go to completed scene.
     */
    private void startRealTraining(double[][] trainData, double[][] testData, int inputSize, double lr) {

        if (trainingProgress == null || epochValueLabel == null) {
            System.out.println("❌ Training UI not loaded yet.");
            return;
        }

        lr = 0.1;  // Good learning rate
        System.out.println("⚠️ OVERRIDE: Forcing learning rate to " + lr);
        System.out.println("✅ startRealTraining called:");
        System.out.println("   trainData rows: " + trainData.length);
        System.out.println("   testData rows: " + testData.length);
        System.out.println("   inputSize: " + inputSize);
        System.out.println("   learningRate: " + lr);

        epochValueLabel.setText("0");

        int totalEpochs = 1000;  // Changed from 5 to 500
        NeuralNetwork nn = new NeuralNetwork(inputSize, lr, 5);  // Keep this as is!  // ✅ Higher LR, more neurons

// Inside the training loop, add occasional logging
        for (int epoch = 1; epoch <= totalEpochs; epoch++) {
            nn.trainingNN(trainData);

            // Log every 100 epochs
            if (epoch % 100 == 0) {
                System.out.println("Epoch " + epoch + " completed");
            }

            final int ep = epoch;
            Platform.runLater(() -> {
                epochValueLabel.setText(String.valueOf(ep));
                trainingProgress.setProgress(ep / (double) totalEpochs);
            });
        }

        // ✅ STORE ALL DATA IN INSTANCE VARIABLES
        this.trainSet = trainData;
        this.testSet = testData;
        this.inputSizeGlobal = inputSize;
        this.learningRateGlobal = lr;

        // Convert arrays to List for global variables
        this.trainSetGlobal = new ArrayList<>();
        for (double[] row : trainData) {
            trainSetGlobal.add(row);
        }

        this.testSetGlobal = new ArrayList<>();
        for (double[] row : testData) {
            testSetGlobal.add(row);
        }

        System.out.println("✅ Stored training data:");
        System.out.println("   trainSetGlobal size: " + trainSetGlobal.size());
        System.out.println("   testSetGlobal size: " + testSetGlobal.size());

        // Background thread so UI does not freeze
        Task<Void> trainTask = new Task<>() {

            @Override
            protected Void call() throws Exception {
                System.out.println("🔄 Training task started!");

                double previousError = Double.MAX_VALUE;
                int noImprovementCount = 0;
                int maxNoImprovement = 50; // Stop if no improvement for 50 epochs

                for (int epoch = 1; epoch <= totalEpochs; epoch++) {

                    // Train multiple times per epoch
                    for (int pass = 0; pass < 3; pass++) {
                        nn.trainingNN(trainData);
                    }

                    // ✅ Check if we should stop early
                    double[] errors = nn.getMSREValues();
                    double avgError = 0;
                    for (double e : errors) {
                        avgError += e;
                    }
                    avgError /= errors.length;

                    // If error improved by less than 0.0001, increment counter
                    if (previousError - avgError < 0.0001) {
                        noImprovementCount++;
                    } else {
                        noImprovementCount = 0;
                    }
                    previousError = avgError;

                    // Stop if no improvement for too long
                    if (noImprovementCount >= maxNoImprovement) {
                        System.out.println("✅ Early stopping at epoch " + epoch + " - no improvement");
                        break;
                    }

                    // Log every 100 epochs
                    if (epoch % 100 == 0) {
                        System.out.println("   Epoch " + epoch + "/" + totalEpochs + " - Avg Error: " + String.format("%.6f", avgError));
                    }

                    // UPDATE UI
                    final int ep = epoch;
                    Platform.runLater(() -> {
                        epochValueLabel.setText(String.valueOf(ep));
                        trainingProgress.setProgress(ep / (double) totalEpochs);
                    });

                    if (epoch % 10 == 0) {
                        Thread.sleep(10);
                    }
                }

                trainedNetwork = nn;
                System.out.println("✅ Training completed! Network saved.");
                return null;
            }

            @Override
            protected void succeeded() {
                System.out.println("✅ Training task succeeded, navigating to completion screen");
                goToTrainingCompleted(totalEpochs);
            }

            @Override
            protected void failed() {
                Throwable ex = getException();
                ex.printStackTrace();
                System.out.println("❌ Training task failed: " + ex.getMessage());
                showError("Training Failed", ex.getMessage());
            }
        };

        Thread th = new Thread(trainTask);
        th.setDaemon(true);
        th.start();
        System.out.println("✅ Training thread started");
    }
    private void startDemoTraining() {
        if (trainingProgress == null) return;

        setCurrentEpoch(0);

        Timeline smoothFill = new Timeline(
                new KeyFrame(Duration.ZERO,
                        new KeyValue(trainingProgress.progressProperty(), 0.0)),
                new KeyFrame(Duration.seconds(5),
                        new KeyValue(trainingProgress.progressProperty(), 1.0))
        );

        // Epoch labels at each second
        smoothFill.getKeyFrames().addAll(
                new KeyFrame(Duration.seconds(1), e -> setCurrentEpoch(1)),
                new KeyFrame(Duration.seconds(2), e -> setCurrentEpoch(2)),
                new KeyFrame(Duration.seconds(3), e -> setCurrentEpoch(3)),
                new KeyFrame(Duration.seconds(4), e -> setCurrentEpoch(4)),
                new KeyFrame(Duration.seconds(5), e -> setCurrentEpoch(5))
        );

        // Defer navigation to next pulse to avoid "showAndWait during animation"
        smoothFill.setOnFinished(e -> Platform.runLater(() -> goToTrainingCompleted(5))); // total epochs = 5 (demo)
        trainingTimeline = smoothFill;
        trainingTimeline.play();
    }

    private void startRealTestingProcess() {

        if (testingProgress == null || testProgressLabel == null) {
            System.out.println("Testing UI not loaded yet.");
            return;
        }

        testProgressLabel.setText("0%");

        Task<Void> testingTask = new Task<>() {

            @Override
            protected Void call() throws Exception {
                updateMessage("0");

                int totalSamples = testSetGlobal.size();
                int done = 0;

                NeuralNetwork nn = trainedNetwork;

                if (nn == null) {
                    throw new RuntimeException("Trained network is null!");
                }

                // ✅ VERIFY THE NETWORK IS TRAINED - Test with a sample
                if (totalSamples > 0) {
                    double[] testSample1 = Arrays.copyOf(testSetGlobal.get(0), inputSizeGlobal);
                    double pred1 = nn.predict(testSample1);
                    System.out.println("🔍 VERIFICATION - First prediction: " + pred1);

                    if (totalSamples > 1) {
                        double[] testSample2 = Arrays.copyOf(testSetGlobal.get(1), inputSizeGlobal);
                        double pred2 = nn.predict(testSample2);
                        System.out.println("🔍 VERIFICATION - Second prediction: " + pred2);

                        if (Math.abs(pred1 - pred2) < 0.001) {
                            System.out.println("⚠️ WARNING: Predictions are too similar - network may not be trained!");
                        }
                    }
                }

                double[] preds = new double[totalSamples];

                System.out.println("🔄 Starting predictions on " + totalSamples + " samples...");

                for (int i = 0; i < testSetGlobal.size(); i++) {
                    double[] row = testSetGlobal.get(i);

                    // ✅ ADD: Extract only input features (exclude target)
                    double[] inputFeatures = Arrays.copyOf(row, inputSizeGlobal);
                    preds[i] = nn.predict(inputFeatures);

                    // ✅ ADD: Log first few predictions
                    if (i < 4) {
                        double actual = row[row.length - 1];
                        System.out.println("Sample " + (i + 1) + ":");
                        System.out.println("   Predicted: " + preds[i]);
                        System.out.println("   Actual: " + actual);
                        System.out.println("   Error: " + Math.abs(preds[i] - actual));
                    }

                    done++;
                    updateProgress(done, totalSamples);
                    updateMessage(String.valueOf((done * 100) / totalSamples));
                }

                predictionsGlobal = preds;
                createPipelineResult(preds);  // ← ADD THIS LINE
                System.out.println("✅ Testing completed! Generated " + preds.length + " predictions");

                return null;
            }

            @Override
            protected void succeeded() {
                super.succeeded();
                Platform.runLater(() -> goToTestingResultsScene());
            }

            @Override
            protected void failed() {
                super.failed();
                Throwable ex = getException();
                ex.printStackTrace();
                Platform.runLater(() ->
                        showError("Testing Failed", ex.getMessage() != null ? ex.getMessage() : ex.toString())
                );
            }
        };

        testingProgress.progressProperty().bind(testingTask.progressProperty());
        testingTask.messageProperty().addListener((o, oldV, newV) ->
                testProgressLabel.setText(newV + "%")
        );

        Thread th = new Thread(testingTask);
        th.setDaemon(true);
        th.start();
    }
    private void createPipelineResult(double[] predictions) {
        if (testSetGlobal == null || trainSetGlobal == null) {
            System.out.println("❌ Cannot create PipelineResult - missing data");
            return;
        }

        // Convert List to array for compatibility
        double[][] testArray = testSetGlobal.toArray(new double[0][]);
        double[][] trainArray = trainSetGlobal.toArray(new double[0][]);

        // Calculate metrics
        double totalError = 0.0;
        double totalSquaredError = 0.0;
        int correctPredictions = 0;
        int totalSamples = predictions.length;

        for (int i = 0; i < totalSamples; i++) {
            double[] testRow = testSetGlobal.get(i);
            double actualValue = testRow[testRow.length - 1];
            double predictedValue = predictions[i];

            double error = actualValue - predictedValue;
            totalError += Math.abs(error);
            totalSquaredError += error * error;

            // Consider prediction correct if within 15% of actual value
            double absError = Math.abs(error);
            if (absError <= 0.10) { // Within 0.10 for normalized data
                correctPredictions++;
            }
            boolean absoluteMatch = absError <= 0.10;
            double relativeError = absError / (Math.abs(actualValue) + 0.0001);
            boolean relativeMatch = relativeError <= 0.20;

            if (absoluteMatch || relativeMatch) {
                correctPredictions++;
            }
        }

        double accuracy = (correctPredictions / (double) totalSamples);
        double mse = totalSquaredError / totalSamples;
        double rmse = Math.sqrt(mse);

        // Create the PipelineResult object
        latestPipelineResult = new PipelineResult(
                predictions,
                testArray,
                trainArray,
                accuracy,
                mse,
                rmse
        );

        System.out.println("✅ PipelineResult created:");
        System.out.println("   Accuracy: " + String.format("%.2f%%", accuracy * 100));
        System.out.println("   MSE: " + mse);
        System.out.println("   RMSE: " + rmse);
    }

    private Stage getCurrentStage() {
        // Try to get stage from any currently loaded FXML element
        if (root != null && root.getScene() != null) {
            return (Stage) root.getScene().getWindow();
        }
        if (normalizingProgress != null && normalizingProgress.getScene() != null) {
            return (Stage) normalizingProgress.getScene().getWindow();
        }
        if (startBtn != null && startBtn.getScene() != null) {
            return (Stage) startBtn.getScene().getWindow();
        }
        if (trainingProgress != null && trainingProgress.getScene() != null) {
            return (Stage) trainingProgress.getScene().getWindow();
        }
        return null;
    }

    private void goToTrainingProcessScene() {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("trainingprocess.fxml"));

            Parent rootNode = loader.load();

            // Get ANY node from the current scene
            Node sourceNode = null;

            // Try to find any initialized node from normalizing scene
            if (normalizingProgress != null) sourceNode = normalizingProgress;
            else if (normalizingStatusLabel != null) sourceNode = normalizingStatusLabel;
            else if (normalizingPercentLabel != null) sourceNode = normalizingPercentLabel;
            else if (root != null) sourceNode = root;

            if (sourceNode == null || sourceNode.getScene() == null) {
                System.err.println("ERROR: No valid node to get stage from!");
                // Last resort - try to find the window differently
                Stage stage = (Stage) Stage.getWindows().stream()
                        .filter(Window::isShowing)
                        .findFirst()
                        .orElse(null);

                if (stage == null) {
                    showError("Navigation Failed", "Unable to get current window reference.");
                    return;
                }

                Scene scene = new Scene(rootNode);
                stage.setScene(scene);
                stage.show();
                return;
            }

            Stage stage = (Stage) sourceNode.getScene().getWindow();
            Scene scene = new Scene(rootNode);
            stage.setScene(scene);
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
            showError("Navigation Failed",
                    "Could not open trainingprocess.fxml\n" + e.getMessage());
        }
    }

    /**
     * Switch to completed scene and pass total epochs.
     */
    private void goToTrainingCompleted(int totalEpochs) {
        if (root == null) return;

        // ✅ STOP ANY RUNNING ANIMATIONS
        stopAllTimelines();

        // ✅ Preserve data BEFORE switching scenes
        preserveTrainingDataForTesting();

        System.out.println("🔍 DEBUG: Data before scene switch:");
        System.out.println("   testSetGlobal size: " + (testSetGlobal != null ? testSetGlobal.size() : "null"));
        System.out.println("   trainSetGlobal size: " + (trainSetGlobal != null ? trainSetGlobal.size() : "null"));
        System.out.println("   trainedNetwork: " + (trainedNetwork != null ? "exists" : "null"));

        Platform.runLater(() -> {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("trainingcompleted.fxml"));
                Parent view = loader.load();

                PrimaryController controller = loader.getController();
                controller.setTotalEpochs(totalEpochs);

                // ✅ TRANSFER ALL THE DATA TO THE NEW CONTROLLER
                controller.testSetGlobal = this.testSetGlobal;
                controller.trainSetGlobal = this.trainSetGlobal;
                controller.trainedNetwork = this.trainedNetwork;
                controller.inputSizeGlobal = this.inputSizeGlobal;
                controller.learningRateGlobal = this.learningRateGlobal;

                System.out.println("✅ Data transferred to trainingcompleted controller:");
                System.out.println("   testSetGlobal size: " + (controller.testSetGlobal != null ? controller.testSetGlobal.size() : "null"));
                System.out.println("   trainSetGlobal size: " + (controller.trainSetGlobal != null ? controller.trainSetGlobal.size() : "null"));
                System.out.println("   trainedNetwork: " + (controller.trainedNetwork != null ? "exists" : "null"));

                Stage stage = (Stage) root.getScene().getWindow();
                stage.setScene(new Scene(view));
                stage.show();
                stage.setTitle("GINICAST - Training Completed");

                Platform.runLater(view::requestFocus);

            } catch (IOException notFound) {
                Alert info = new Alert(Alert.AlertType.INFORMATION);
                info.setTitle("Training Completed");
                info.setHeaderText("Training finished (demo).");
                info.setContentText("`trainingcompleted.fxml` not found. Returning to the main screen.");
                if (root.getScene() != null) {
                    info.initOwner(root.getScene().getWindow());
                }
                info.setResizable(false);
                info.show();
                info.setOnHidden(ev -> switchToNode(root, "primary.fxml", "GINICAST"));
            }
        });
    }

    // ------------------------ Scene 5: trainingcompleted.fxml ------------------------

    /**
     * Set the total epochs shown under "Total Epochs" capsule.
     */
    public void setTotalEpochs(int total) {
        if (totalEpochsLabel != null) {
            totalEpochsLabel.setText(String.valueOf(total));
        }
    }
    private void preserveTrainingDataForTesting() {
        System.out.println("🔍 DEBUG: Attempting to preserve training data...");

        // Try using the instance variables first (trainSet, testSet)
        if (testSet != null && testSet.length > 0) {
            testSetGlobal = new ArrayList<>();
            for (double[] row : testSet) {
                testSetGlobal.add(row);
            }
            System.out.println("✅ Preserved test data from testSet: " + testSetGlobal.size() + " samples");
        } else if (pendingTestData != null && !pendingTestData.isEmpty()) {
            testSetGlobal = new ArrayList<>(pendingTestData);
            System.out.println("✅ Preserved test data from pendingTestData: " + testSetGlobal.size() + " samples");
        } else {
            System.out.println("❌ WARNING: No test data available!");
        }

        if (trainSet != null && trainSet.length > 0) {
            trainSetGlobal = new ArrayList<>();
            for (double[] row : trainSet) {
                trainSetGlobal.add(row);
            }
            System.out.println("✅ Preserved train data from trainSet: " + trainSetGlobal.size() + " samples");
        } else if (pendingTrainData != null && !pendingTrainData.isEmpty()) {
            trainSetGlobal = new ArrayList<>(pendingTrainData);
            System.out.println("✅ Preserved train data from pendingTrainData: " + trainSetGlobal.size() + " samples");
        } else {
            System.out.println("❌ WARNING: No train data available!");
        }

        inputSizeGlobal = (inputSizeGlobal > 0) ? inputSizeGlobal : pendingInputSize;
        learningRateGlobal = (learningRateGlobal > 0) ? learningRateGlobal : pendingLearningRate;

        System.out.println("   inputSizeGlobal: " + inputSizeGlobal);
        System.out.println("   learningRateGlobal: " + learningRateGlobal);
    }
    /**
     * Start Testing button → go to starttesting.fxml (or inform if missing).
     */
    @FXML
    private void handleStartTesting(ActionEvent event) {
        // DEBUG: Check if resource exists
        java.net.URL resourceUrl = getClass().getResource("/pnw/ginicast/starttesting.fxml");
        System.out.println("🔍 DEBUG: starttesting.fxml URL = " + resourceUrl);

        if (resourceUrl == null) {
            System.err.println("❌ ERROR: starttesting.fxml NOT FOUND!");
            return;
        } else {
            System.out.println("✅ SUCCESS: starttesting.fxml found at: " + resourceUrl);
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/pnw/ginicast/starttesting.fxml"));
            Parent view = loader.load();

            // ✅ GET THE NEW CONTROLLER AND TRANSFER ALL DATA
            PrimaryController newController = loader.getController();
            newController.testSetGlobal = this.testSetGlobal;
            newController.trainSetGlobal = this.trainSetGlobal;
            newController.trainedNetwork = this.trainedNetwork;
            newController.inputSizeGlobal = this.inputSizeGlobal;
            newController.learningRateGlobal = this.learningRateGlobal;

            System.out.println("✅ Data transferred to testing screen:");
            System.out.println("   Test data size: " + (testSetGlobal != null ? testSetGlobal.size() : "null"));
            System.out.println("   Train data size: " + (trainSetGlobal != null ? trainSetGlobal.size() : "null"));
            System.out.println("   Trained network: " + (trainedNetwork != null ? "exists" : "null"));

            // ✅ POPULATE THE MODEL SELECTOR
            newController.populateModelSelector();

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(view));
            stage.setTitle("GINICAST - Start Testing");
            stage.show();

            Platform.runLater(view::requestFocus);
        } catch (IOException notFound) {
            notFound.printStackTrace();
            Alert info = new Alert(Alert.AlertType.ERROR);
            info.setTitle("Start Testing");
            info.setHeaderText("Start Testing view not found.");
            info.setContentText("Error: " + notFound.getMessage());
            if (root != null && root.getScene() != null) {
                info.initOwner(root.getScene().getWindow());
            }
            info.showAndWait();
        }
    }

    /**
     * Save Model button:
     * - Ask for a name
     * - Save under ./models/
     * - Allow Cancel
     * - Confirm overwrite if exists
     */
    @FXML
    private void handleSaveModel(ActionEvent event) {
        // 1) Ask for a model name with a simple default
        TextInputDialog dlg = new TextInputDialog(defaultModelName());
        dlg.setTitle("Save Model");
        dlg.setHeaderText("Enter a name for the trained model");
        dlg.setContentText("Model name:");
        if (root != null && root.getScene() != null) {
            dlg.initOwner(root.getScene().getWindow());
        }

        Optional<String> result = dlg.showAndWait();
        if (result.isEmpty()) {
            // user cancelled
            return;
        }

        String rawName = result.get().trim();
        if (rawName.isEmpty()) {
            showError("Invalid name", "Model name cannot be empty.");
            return;
        }

        // 2) Sanitize filename (letters/digits/_/-/.)
        String safeName = rawName.replaceAll("[^A-Za-z0-9_\\-\\.]", "_");
        if (!safeName.toLowerCase().endsWith(".model")) {
            safeName = safeName + ".model";
        }

        // 3) Ensure ./models directory exists (relative to working dir)
        Path modelsDir = Paths.get(System.getProperty("user.dir"), "models");
        try {
            Files.createDirectories(modelsDir);
        } catch (IOException e) {
            showError("Cannot create folder",
                    "Failed to create models directory:\n" + modelsDir.toAbsolutePath());
            return;
        }

        Path target = modelsDir.resolve(safeName);

        // 4) Confirm overwrite if exists
        if (Files.exists(target)) {
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Overwrite Model");
            confirm.setHeaderText("A model with this name already exists.");
            confirm.setContentText("Overwrite " + target.getFileName() + "?");
            if (root != null && root.getScene() != null) {
                confirm.initOwner(root.getScene().getWindow());
            }
            Optional<ButtonType> choice = confirm.showAndWait();
            if (choice.isEmpty() || choice.get() != ButtonType.OK) {
                return;
            }
        }

        // 5) Save the actual trained model + test data
        try {
            // Create a container for model + data
            Map<String, Object> modelData = new HashMap<>();
            modelData.put("trainedNetwork", trainedNetwork);  // Your trained neural network
            modelData.put("testData", testSetGlobal);         // Your test dataset
            modelData.put("inputSize", inputSizeGlobal);      // Input size
            modelData.put("learningRate", learningRateGlobal); // Learning rate
            modelData.put("savedAt", LocalDateTime.now().toString());
            modelData.put("modelName", safeName);

            // Serialize to file using ObjectOutputStream
            try (ObjectOutputStream oos = new ObjectOutputStream(
                    new FileOutputStream(target.toFile()))) {
                oos.writeObject(modelData);
            }

            Alert ok = new Alert(Alert.AlertType.INFORMATION);
            ok.setTitle("Model Saved");
            ok.setHeaderText("Model saved successfully.");
            ok.setContentText("Path:\n" + target.toAbsolutePath());
            if (root != null && root.getScene() != null) {
                ok.initOwner(root.getScene().getWindow());
            }
            ok.setResizable(false);
            ok.showAndWait();

        } catch (IOException e) {
            showError("Save failed", "Could not save the model:\n" + e.getMessage());
        }
    }
    // ------------------------ Scene 6: starttesting.fxml ------------------------
    private void populateModelSelector() {
        if (modelSelector == null) return;

        // Clear existing items
        modelSelector.getItems().clear();

        // Add default option
        modelSelector.getItems().add("Use Default Model");

        // Scan models folder for available models
        File modelsDir = new File("models");
        if (modelsDir.exists() && modelsDir.isDirectory()) {
            File[] modelFiles = modelsDir.listFiles((dir, name) ->
                    name.endsWith(".h5") || name.endsWith(".keras") ||
                            name.endsWith(".model") || name.endsWith(".pkl") ||
                            name.endsWith(".joblib") || name.endsWith(".sav"));

            if (modelFiles != null && modelFiles.length > 0) {
                for (File modelFile : modelFiles) {
                    modelSelector.getItems().add(modelFile.getName());
                }
            } else {
                // If no models found, add a placeholder
                modelSelector.getItems().add("No models found in models folder");
            }
        } else {
            // If models directory doesn't exist
            modelSelector.getItems().add("Models folder not found");
        }

        // Set default selection
        modelSelector.getSelectionModel().selectFirst();
        updateSelectedModelLabel();
    }

    private void setupModelSelectionHandlers() {
        if (modelSelector != null) {
            modelSelector.setOnAction(e -> handleModelSelection());
        }
    }

    private void handleModelSelection() {
        updateSelectedModelLabel();
    }

    private void updateSelectedModelLabel() {
        if (selectedModelLabel == null || modelSelector == null) return;

        String selected = modelSelector.getValue();
        if (selected == null || selected.equals("Use Default Model")) {
            selectedModelLabel.setText("Using default model");
        } else if (selected.startsWith("No models") || selected.startsWith("Models folder")) {
            selectedModelLabel.setText(selected);
        } else {
            selectedModelLabel.setText("Selected: " + selected);
        }
    }

    /**
     * Start Testing button in testing scene
     */
    @FXML
    private void startTesting(ActionEvent event) {
        // Check if we have test data
        if (testSetGlobal == null || testSetGlobal.isEmpty()) {
            showError("Testing Error", "No test data available. Please either:\n" +
                    "1. Run training first, OR\n" +
                    "2. Select a saved model from the dropdown");
            return;
        }

        // Check if we have a trained network
        if (trainedNetwork == null) {
            showError("Testing Error", "No trained model available. Please either:\n" +
                    "1. Run training first, OR\n" +
                    "2. Select a saved model from the dropdown");
            return;
        }

        System.out.println("✅ Starting testing with:");
        System.out.println("   Model: " + selectedModel);
        System.out.println("   Test data size: " + testSetGlobal.size());
        System.out.println("   Trained network: " + (trainedNetwork != null ? "exists" : "null"));

        // Navigate to testing process scene
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("testingprocess.fxml"));
            Parent view = loader.load();

            // ✅ GET THE NEW CONTROLLER AND TRANSFER DATA
            PrimaryController newController = loader.getController();
            newController.testSetGlobal = this.testSetGlobal;
            newController.trainSetGlobal = this.trainSetGlobal;
            newController.trainedNetwork = this.trainedNetwork;
            newController.inputSizeGlobal = this.inputSizeGlobal;
            newController.learningRateGlobal = this.learningRateGlobal;

            System.out.println("✅ Data transferred to testing controller");

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(view));
            stage.setTitle("GINICAST - Testing Process");
            stage.show();

            // ✅ START THE TESTING PROCESS ON THE NEW CONTROLLER
            Platform.runLater(newController::startRealTestingProcess);

        } catch (IOException e) {
            e.printStackTrace();
            showError("Navigation Error", "Unable to load testing process: " + e.getMessage());
        }
    }
    @FXML
    private void handleModelSelection(ActionEvent event) {
        String selected = modelSelector.getValue();
        if (selected == null || selected.isEmpty()) {
            return;
        }

        selectedModel = selected;
        if (selectedModelLabel != null) {
            selectedModelLabel.setText("Selected: " + selected);
        }

        // Load the model file
        Path modelsDir = Paths.get(System.getProperty("user.dir"), "models");
        Path modelPath = modelsDir.resolve(selected);

        if (!Files.exists(modelPath)) {
            showError("Model Not Found", "The selected model file does not exist:\n" + modelPath);
            return;
        }

        try {
            // Load the saved model data
            try (ObjectInputStream ois = new ObjectInputStream(
                    new FileInputStream(modelPath.toFile()))) {

                @SuppressWarnings("unchecked")
                Map<String, Object> modelData = (Map<String, Object>) ois.readObject();

                // Restore all the data
                trainedNetwork = (NeuralNetwork) modelData.get("trainedNetwork");
                testSetGlobal = (List<double[]>) modelData.get("testData");
                inputSizeGlobal = (Integer) modelData.get("inputSize");
                learningRateGlobal = (Double) modelData.get("learningRate");

                System.out.println("✅ Model loaded successfully!");
                System.out.println("   Test data size: " + testSetGlobal.size());
                System.out.println("   Input size: " + inputSizeGlobal);

            }
        } catch (IOException | ClassNotFoundException e) {
            showError("Load Error", "Failed to load model:\n" + e.getMessage());
            e.printStackTrace();
        }
    }
    private void goToScene(String fxml, String title, Event event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml));
            Parent view = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(view));
            stage.setTitle(title);
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
            showError("Navigation Error", "Unable to load: " + fxml);
        }
    }

    /**
     * Back button in testing scene
     */
    @FXML
    private void goBack(ActionEvent event) {
        switchTo(event, "trainingcompleted.fxml", "GINICAST - Training Completed");
    }

    // ------------------------ Scene 7: testingprocess.fxml ------------------------

    /**
     * Setup ESC key for testing process
     */
    private void setupTestingEscToExit() {
        if (root == null) return;

        root.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if (e.getCode() == KeyCode.ESCAPE) {
                e.consume();
                if (testingTimeline != null) testingTimeline.pause();

                Platform.runLater(() -> {
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("Confirm Exit");
                    alert.setHeaderText("Are you sure you wish to exit testing?");
                    alert.setContentText("Testing progress will be stopped and you will return to the main screen.");
                    alert.getButtonTypes().setAll(ButtonType.YES, ButtonType.NO);
                    if (root.getScene() != null) {
                        alert.initOwner(root.getScene().getWindow());
                    }
                    alert.setResizable(false);

                    Optional<ButtonType> result = alert.showAndWait();
                    if (result.isPresent() && result.get() == ButtonType.YES) {
                        if (testingTimeline != null) testingTimeline.stop();
                        switchToNode(root, "primary.fxml", "GINICAST");
                    } else {
                        if (testingTimeline != null) testingTimeline.play();
                    }
                });
            }
        });
    }

    /**
     * 3-second demo testing process
     */
    private void startDemoTesting() {
        if (testingProgress == null || testProgressLabel == null) return;

        // ✅ REMOVE THIS LINE - can't set on bound property
        // testingProgress.setProgress(0);  // ❌ DELETE THIS
        testProgressLabel.setText("0%");

        Timeline testingFill = new Timeline(
                new KeyFrame(Duration.ZERO,
                        new KeyValue(testingProgress.progressProperty(), 0.0)),
                new KeyFrame(Duration.seconds(3),
                        new KeyValue(testingProgress.progressProperty(), 1.0))
        );

        // Update progress percentage every 0.5 seconds
        testingFill.getKeyFrames().addAll(
                new KeyFrame(Duration.seconds(0.5), e -> updateTestProgress(17)),
                new KeyFrame(Duration.seconds(1.0), e -> updateTestProgress(33)),
                new KeyFrame(Duration.seconds(1.5), e -> updateTestProgress(50)),
                new KeyFrame(Duration.seconds(2.0), e -> updateTestProgress(67)),
                new KeyFrame(Duration.seconds(2.5), e -> updateTestProgress(83)),
                new KeyFrame(Duration.seconds(3.0), e -> updateTestProgress(100))
        );

        testingFill.setOnFinished(e -> Platform.runLater(this::goToTestingResultsScene));
        testingTimeline = testingFill;
        testingTimeline.play();
    }

    private void updateTestProgress(int percent) {
        if (testProgressLabel != null) {
            testProgressLabel.setText(percent + "%");
        }
    }
    private void goToTestingResultsScene() {
        // ✅ STOP ANY RUNNING ANIMATIONS
        stopAllTimelines();

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("testingresults.fxml"));
            Parent view = loader.load();

            PrimaryController controller = loader.getController();
            controller.predictionsGlobal = this.predictionsGlobal;
            controller.testSetGlobal = this.testSetGlobal;
            controller.trainSetGlobal = this.trainSetGlobal;
            controller.trainedNetwork = this.trainedNetwork;
            controller.latestPipelineResult = this.latestPipelineResult;  // ← ADD THIS LINE

            System.out.println("✅ Data transferred to results screen:");
            System.out.println("   Predictions: " + (predictionsGlobal != null ? predictionsGlobal.length : "null"));
            System.out.println("   Test data: " + (testSetGlobal != null ? testSetGlobal.size() : "null"));

            Stage stage = null;
            if (root != null && root.getScene() != null) {
                stage = (Stage) root.getScene().getWindow();
            }

            if (stage == null) {
                stage = (Stage) Stage.getWindows().stream()
                        .filter(Window::isShowing)
                        .findFirst()
                        .orElse(null);
            }

            if (stage == null) {
                showError("Navigation Error", "Cannot find application window");
                return;
            }

            stage.setScene(new Scene(view));
            stage.setTitle("GINICAST - Testing Results");
            stage.show();

            // ✅ UPDATED: Call both methods on the new controller instance
            Platform.runLater(() -> {
                controller.initializeTestingResults();
                controller.displayPredictionChart();  // ADD THIS LINE
            });
            Platform.runLater(view::requestFocus);

        } catch (Exception e) {
            e.printStackTrace();
            showError("Navigation Failed", "Could not open testingresults.fxml: " + e.getMessage());
        }
    }
    /**
     * Initialize the testing results screen with calculated metrics
     */
    private void initializeTestingResults() {
        if (predictionsGlobal == null || testSetGlobal == null ||
                predictionsGlobal.length == 0 || testSetGlobal.isEmpty()) {
            showError("Results Error", "No predictions or test data available!");
            return;
        }

        System.out.println("🔍 Initializing results with " + predictionsGlobal.length + " predictions");

        // Calculate metrics
        double totalError = 0.0;
        double totalSquaredError = 0.0;
        int correctPredictions = 0;
        int totalSamples = predictionsGlobal.length;

        // ✅ ADD DEBUG OUTPUT
        System.out.println("\n=== PREDICTION DEBUG ===");
        for (int i = 0; i < Math.min(5, totalSamples); i++) {  // Show first 5 predictions
            double[] testRow = testSetGlobal.get(i);
            double actualValue = testRow[testRow.length - 1];
            double predictedValue = predictionsGlobal[i];

            System.out.println("Sample " + i + ":");
            System.out.println("  Predicted: " + predictedValue);
            System.out.println("  Actual: " + actualValue);
            System.out.println("  Error: " + Math.abs(actualValue - predictedValue));
        }
        System.out.println("=======================\n");

        for (int i = 0; i < totalSamples; i++) {
            double[] testRow = testSetGlobal.get(i);
            double actualValue = testRow[testRow.length - 1];
            double predictedValue = predictionsGlobal[i];

            double error = actualValue - predictedValue;
            double absError = Math.abs(error);
            totalError += absError;
            totalSquaredError += error * error;

            // For normalized data (0-1 range), use absolute threshold
            if (absError <= 0.10) { // Within 0.10 for normalized data
                correctPredictions++;
            }

            // Debug first few predictions
            if (i < 5) {
                System.out.println("Sample " + i + ": Pred=" + String.format("%.4f", predictedValue) +
                        ", Actual=" + String.format("%.4f", actualValue) +
                        ", Error=" + String.format("%.4f", absError) +
                        ", Match=" + (absError <= 0.10));
            }
        }

        // Calculate final metrics
        double accuracy = (correctPredictions / (double) totalSamples) * 100.0;
        double mse = totalSquaredError / totalSamples;
        double rmse = Math.sqrt(mse);

        // Update UI labels
        if (accuracyLabel != null) {
            accuracyLabel.setText(String.format("%.2f%%", accuracy));
        }
        if (mseLabel != null) {
            mseLabel.setText(String.format("%.4f", mse));
        }
        if (rmseLabel != null) {
            rmseLabel.setText(String.format("%.4f", rmse));
        }

        System.out.println("✅ Results calculated:");
        System.out.println("   Correct predictions: " + correctPredictions + "/" + totalSamples);
        System.out.println("   Accuracy: " + String.format("%.2f%%", accuracy));
        System.out.println("   MSE: " + String.format("%.4f", mse));
        System.out.println("   RMSE: " + String.format("%.4f", rmse));
    }
    private void displayPredictionChart() {
        if (resultsGraphBox == null) {
            System.out.println("❌ resultsGraphBox is null - cannot display chart");
            return;
        }

        if (predictionsGlobal == null || testSetGlobal == null) {
            System.out.println("❌ Cannot display chart - missing data");
            System.out.println("   predictionsGlobal: " + (predictionsGlobal != null ? predictionsGlobal.length : "null"));
            System.out.println("   testSetGlobal: " + (testSetGlobal != null ? testSetGlobal.size() : "null"));
            return;
        }

        try {
            System.out.println("📊 Creating prediction chart...");

            // Create chart axes
            CategoryAxis xAxis = new CategoryAxis();
            NumberAxis yAxis = new NumberAxis();

            xAxis.setLabel("Sample");
            yAxis.setLabel("Value");

            LineChart<String, Number> chart = new LineChart<>(xAxis, yAxis);
            chart.setTitle("Predictions vs Actual Values");
            chart.setLegendVisible(true);
            chart.setCreateSymbols(true);

            // Predicted values series
            XYChart.Series<String, Number> predictedSeries = new XYChart.Series<>();
            predictedSeries.setName("Predicted");

            // Actual values series
            XYChart.Series<String, Number> actualSeries = new XYChart.Series<>();
            actualSeries.setName("Actual");

            // Add data points
            int numPoints = Math.min(predictionsGlobal.length, testSetGlobal.size());
            System.out.println("   Adding " + numPoints + " data points to chart");

            for (int i = 0; i < numPoints; i++) {
                String sampleLabel = "S" + (i + 1);

                // Predicted value
                predictedSeries.getData().add(
                        new XYChart.Data<>(sampleLabel, predictionsGlobal[i])
                );

                // Actual value (last column in the data)
                double[] row = testSetGlobal.get(i);
                double actualValue = row[row.length - 1];
                actualSeries.getData().add(
                        new XYChart.Data<>(sampleLabel, actualValue)
                );
            }

            chart.getData().addAll(actualSeries, predictedSeries);

            // Style the chart
            chart.setStyle("-fx-background-color: white; -fx-padding: 20;");
            chart.setPrefHeight(350);
            chart.setPrefWidth(800);

            // Add to UI
            resultsGraphBox.getChildren().clear();
            resultsGraphBox.getChildren().add(chart);

            System.out.println("✅ Chart created and displayed successfully!");

        } catch (Exception e) {
            System.err.println("❌ Error creating chart: " + e.getMessage());
            e.printStackTrace();
        }
    }
    @FXML
    private void goToPrimaryFromResults(ActionEvent event) {
        switchTo(event, "primary.fxml", "GINICAST");
    }

    // Helper method to show info alerts
    private void showInfo(String title, String content) {
        Alert info = new Alert(Alert.AlertType.INFORMATION);
        info.setTitle(title);
        info.setHeaderText(null);
        info.setContentText(content);
        if (root != null && root.getScene() != null) {
            info.initOwner(root.getScene().getWindow());
        }
        info.setResizable(false);
        info.showAndWait();
    }

    /**
     * Setup demo results for testing results scene
     */
    private void setupDemoResults() {
        if (latestPipelineResult == null || latestPipelineResult.getTrainingResult() == null) {
            if (accuracyLabel != null) accuracyLabel.setText("No data");
            if (mseLabel != null) mseLabel.setText("No data");
            if (rmseLabel != null) rmseLabel.setText("No data");
            return;
        }

        double acc = latestPipelineResult.getAccuracy();
        double mse = latestPipelineResult.getMSE();
        double rmse = latestPipelineResult.getRMSE();

        if (accuracyLabel != null) accuracyLabel.setText(String.format("%.2f%%", acc * 100));
        if (mseLabel != null) mseLabel.setText(String.format("%.5f", mse));
        if (rmseLabel != null) rmseLabel.setText(String.format("%.5f", rmse));
    }

    // ==================== STEP 2B: Load Results into TestingResults.fxml ====================
    // ================= STEP 3: Load Results into TestingResults.fxml ================
    private void populateTestingResults() {

        // No results → show default zeros
        if (latestPipelineResult == null || latestPipelineResult.isEmpty()) {
            accuracyLabel.setText("0%");
            mseLabel.setText("0.0000");
            rmseLabel.setText("0.0000");
            return;
        }

        // Fill labels with formatted values from PipelineResult
        accuracyLabel.setText(latestPipelineResult.getAccuracyFormatted());
        mseLabel.setText(latestPipelineResult.getMseFormatted());
        rmseLabel.setText(latestPipelineResult.getRmseFormatted());

        // OPTIONAL: Later you can use this to draw graphs in results screen
        double[] preds = latestPipelineResult.getPredictions();
        double[][] testSet = latestPipelineResult.getTestSet();
        drawResultsGraph();

        // Example: clear graph box for dynamic plotting
        // resultsGraphBox.getChildren().clear();
        // resultsGraphBox.getChildren().add( ... some graph node ... );
    }

    @FXML
    private void saveResultsText() {
        try {
            // Check both latestPipelineResult AND raw data
            boolean hasResultData = (latestPipelineResult != null && !latestPipelineResult.isEmpty());
            boolean hasRawData = (predictionsGlobal != null && testSetGlobal != null &&
                    predictionsGlobal.length > 0 && !testSetGlobal.isEmpty());

            if (!hasResultData && !hasRawData) {
                new Alert(Alert.AlertType.WARNING, "No results available to save.").showAndWait();
                return;
            }

            FileChooser fc = new FileChooser();
            fc.setTitle("Save Results as Text");
            fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files", "*.txt"));
            fc.setInitialFileName("testing_results.txt");

            File file = fc.showSaveDialog(null);
            if (file == null) return;

            PrintWriter pw = new PrintWriter(file);

            pw.println("===== Neural Network Testing Results =====");
            pw.println("Timestamp: " + LocalDateTime.now());
            pw.println("------------------------------------------");

            // Use PipelineResult if available, otherwise calculate
            if (hasResultData) {
                pw.println("Accuracy : " + latestPipelineResult.getAccuracyFormatted());
                pw.println("MSE      : " + latestPipelineResult.getMseFormatted());
                pw.println("RMSE     : " + latestPipelineResult.getRmseFormatted());
                pw.println();
                pw.println("===== Dataset Information =====");
                pw.println("Training Samples : " + latestPipelineResult.getTrainSet().length);
                pw.println("Testing Samples  : " + latestPipelineResult.getTestSet().length);
                pw.println();
                pw.println("===== Predictions =====");
                double[] preds = latestPipelineResult.getPredictions();
                for (int i = 0; i < preds.length; i++) {
                    double actual = latestPipelineResult.getTestSet()[i][latestPipelineResult.getTestSet()[i].length - 1];
                    pw.println("Test[" + i + "] -> Predicted: " + String.format("%.4f", preds[i]) +
                            ", Actual: " + String.format("%.4f", actual) +
                            ", Error: " + String.format("%.4f", Math.abs(preds[i] - actual)));
                }
            } else {
                // Use raw data
                double totalSquaredError = 0.0;
                int correctPredictions = 0;

                for (int i = 0; i < predictionsGlobal.length; i++) {
                    double[] testRow = testSetGlobal.get(i);
                    double actualValue = testRow[testRow.length - 1];
                    double predictedValue = predictionsGlobal[i];
                    double error = actualValue - predictedValue;
                    totalSquaredError += error * error;

                    double absError = Math.abs(error);
                    if (absError <= 0.10) {
                        correctPredictions++;
                    }
                }

                double accuracy = (correctPredictions / (double) predictionsGlobal.length) * 100.0;
                double mse = totalSquaredError / predictionsGlobal.length;
                double rmse = Math.sqrt(mse);

                pw.println("Accuracy : " + String.format("%.2f%%", accuracy));
                pw.println("MSE      : " + String.format("%.4f", mse));
                pw.println("RMSE     : " + String.format("%.4f", rmse));
                pw.println();
                pw.println("===== Dataset Information =====");
                pw.println("Training Samples : " + (trainSetGlobal != null ? trainSetGlobal.size() : 0));
                pw.println("Testing Samples  : " + testSetGlobal.size());
                pw.println();
                pw.println("===== Predictions =====");
                for (int i = 0; i < predictionsGlobal.length; i++) {
                    double actual = testSetGlobal.get(i)[testSetGlobal.get(i).length - 1];
                    pw.println("Test[" + i + "] -> Predicted: " + String.format("%.4f", predictionsGlobal[i]) +
                            ", Actual: " + String.format("%.4f", actual) +
                            ", Error: " + String.format("%.4f", Math.abs(predictionsGlobal[i] - actual)));
                }
            }

            pw.close();

            new Alert(Alert.AlertType.INFORMATION, "Results saved successfully!").showAndWait();

        } catch (Exception e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Failed to save results:\n" + e.getMessage()).showAndWait();
        }
    }

    @FXML
    private void saveResultsGraph() {

        if (resultsGraphBox == null) {
            showAlert("Save Failed", "Graph area not found.");
            return;
        }

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Graph Screenshot");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PNG Image", "*.png"));

        File file = fileChooser.showSaveDialog(null);
        if (file == null) return;

        try {
            WritableImage snapshot = resultsGraphBox.snapshot(new SnapshotParameters(), null);
            ImageIO.write(SwingFXUtils.fromFXImage(snapshot, null), "png", file);

            showAlert("Success", "Graph saved as PNG!");

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Failed to save graph.");
        }
    }

    private void drawResultsGraph() {
        resultsGraphBox.getChildren().clear();

        if (latestPipelineResult == null || latestPipelineResult.isEmpty()) {
            Label noData = new Label("No graph data available");
            noData.setStyle("-fx-font-size: 16; -fx-text-fill: #666;");
            resultsGraphBox.getChildren().add(noData);
            return;
        }

        double[][] test = latestPipelineResult.getTestSet();
        double[] preds = latestPipelineResult.getPredictions();

        // X-axis = sample index
        NumberAxis xAxis = new NumberAxis();
        xAxis.setLabel("Sample Index");

        // Y-axis = predicted/actual values
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Value");

        LineChart<Number, Number> chart = new LineChart<>(xAxis, yAxis);
        chart.setTitle("Predicted vs Actual");
        chart.setPrefHeight(300);
        chart.setLegendVisible(true);

        XYChart.Series<Number, Number> actualSeries = new XYChart.Series<>();
        actualSeries.setName("Actual");

        XYChart.Series<Number, Number> predictedSeries = new XYChart.Series<>();
        predictedSeries.setName("Predicted");

        for (int i = 0; i < preds.length; i++) {
            double actual = test[i][test[i].length - 1];  // last column = target
            actualSeries.getData().add(new XYChart.Data<>(i, actual));
            predictedSeries.getData().add(new XYChart.Data<>(i, preds[i]));
        }

        chart.getData().addAll(actualSeries, predictedSeries);

        resultsGraphBox.getChildren().add(chart);
    }

    // ------------------------ RESULTS SCREEN DATA BINDING ------------------------
    public void displayPipelineResults(PipelineResult result) {
        if (result == null) return;

        // 1. Display Accuracy
        if (accuracyLabel != null) {
            accuracyLabel.setText(String.format("%.2f%%", result.getAccuracy() * 100));
        }

        // 2. Display MSE
        if (mseLabel != null) {
            mseLabel.setText(String.format("%.4f", result.getMSE()));
        }

        // 3. Display RMSE
        if (rmseLabel != null) {
            rmseLabel.setText(String.format("%.4f", result.getRMSE()));
        }

        // 4. (Optional) Later we will display graph inside resultsGraphBox
        // For now just print
        System.out.println("Results displayed on UI");
    }

    private void showAlert(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    // ------------------------ NEW: Run Full Pipeline (real ML + NN) ------------------------
    @FXML
    private void handleRunFullPipeline(ActionEvent event) {

        if (SELECTED_FILE == null) {
            showError("No CSV Selected", "Please import a CSV file before running the pipeline.");
            return;
        }

        // Read GUI parameters (learning rate & split)
        // Number of input features is taken from data, NOT from nodesField.
        double lr = parseDoubleOrDefault(lrField, 0.001);
        double split = (splitSlider != null ? splitSlider.getValue() : 70) / 100.0;
        learningRateGlobal = lr;

        // POPUP so user sees progress
        Alert popup = new Alert(Alert.AlertType.INFORMATION);
        popup.setTitle("Processing...");
        popup.setHeaderText("Running Full Machine Learning Pipeline");
        popup.setContentText("Please wait...");
        popup.getDialogPane().lookupButton(ButtonType.OK).setDisable(true);
        popup.setResizable(false);
        if (root != null && root.getScene() != null) {
            popup.initOwner(root.getScene().getWindow());
        }
        popup.show();

        // ---------------- BACKGROUND WORKER ----------------
        Task<Void> task = new Task<>() {

            @Override
            protected Void call() throws Exception {

                updateMessage("Reading CSV...");

                // ========== STEP 1: READ CSV ==========
                CSVReader reader = new CSVReader(SELECTED_FILE.getAbsolutePath());

                if (!reader.checkFile())
                    throw new Exception("CSV file invalid or empty.");

                List<String[]> rows = reader.getRows();
                int numRows = reader.getNumberRows();
                int numCols = reader.getNumberColumns();
                String[] header = reader.getHeader();

                int MAX_ROWS_FOR_DEMO = 500;

                if (rows.size() > MAX_ROWS_FOR_DEMO) {
                    rows = rows.subList(0, MAX_ROWS_FOR_DEMO);
                    numRows = rows.size();
                    System.out.println("Demo mode: using first " + numRows + " rows from real dataset.");
                }

                String[] types = new String[numCols];
                for (int i = 0; i < numCols; i++) types[i] = "double";

                updateMessage("Removing incomplete rows...");

                // ========== STEP 2: REMOVE BAD ROWS ==========
                RemoveRows rr = new RemoveRows(rows, numRows, numCols);
                if (rr.isEmpty())
                    throw new Exception("All rows removed in RemoveRows stage.");
                rows = rr.getRows();
                numRows = rows.size();

                updateMessage("Removing outliers...");

                // ========== STEP 3: REMOVE OUTLIERS ==========
//                Outliers out = new Outliers(rows, types, numRows);
//                if (out.isEmpty())
//                    throw new Exception("All rows removed in Outliers stage.");
//                rows = out.getRows();
                System.out.println("⚠️ Outlier removal disabled - keeping all " + rows.size() + " rows");
                numRows = rows.size();

                updateMessage("Cleaning missing values (KNN)...");

                // ========== STEP 4: CLEAN MISSING VALUES ==========
                Cleaning clean = new Cleaning(rows, header, types, 3);
                rows = clean.getRows();
                numRows = rows.size();

                updateMessage("Normalizing to 0–1 scale...");

                // ========== STEP 5: NORMALIZATION ==========
                Normalizer norm = new Normalizer(rows, types);
                double[][] normalized = norm.getRows();

                if (normalized.length == 0)
                    throw new Exception("Normalization failed: empty dataset.");

                inputSizeGlobal = normalized[0].length - 1;

                updateMessage("Splitting into train/test...");

                // ========== STEP 6: SPLIT DATASET ==========
                TestingTrainingSet tts = new TestingTrainingSet(normalized, split);

                // ✅ Convert double[][] to List<double[]>
                trainSetGlobal = Arrays.asList(tts.getTrainingSet());
                testSetGlobal = Arrays.asList(tts.getTestingSet());
                learningRateGlobal = lr;

                System.out.println("✅ DATA SET! trainSetGlobal size: " + trainSetGlobal.size());
                System.out.println("✅ testSetGlobal size: " + testSetGlobal.size());
                System.out.println("✅ First row length: " + trainSetGlobal.get(0).length);

                // ✅ FIX: Check the GLOBAL variables
                if (trainSetGlobal == null || trainSetGlobal.isEmpty() ||
                        testSetGlobal == null || testSetGlobal.isEmpty())
                    throw new Exception("Train/Test split failed.");

                updateMessage("Data preparation complete!");

                // ✅ DON'T TRAIN HERE - we'll train in the UI

                return null;
            }

            @Override
            protected void succeeded() {
                popup.close();

                if (trainSetGlobal == null || trainSetGlobal.isEmpty()) {
                    showError("Data Error", "Training data was not prepared correctly.");
                    return;
                }

                System.out.println("✅ Task succeeded! trainSetGlobal has " + trainSetGlobal.size() + " samples");

                // ✅ Store data in static variables BEFORE loading the scene
                pendingTrainData = trainSetGlobal;
                pendingTestData = testSetGlobal;
                pendingInputSize = inputSizeGlobal;
                pendingLearningRate = learningRateGlobal;

                System.out.println("✅ Data stored in static pending variables");

                Platform.runLater(() -> {
                    try {
                        FXMLLoader loader = new FXMLLoader(getClass().getResource("training.fxml"));
                        Parent view = loader.load();

                        // ✅ GET THE CONTROLLER AND TRANSFER DATA
                        PrimaryController trainingController = loader.getController();
                        trainingController.trainSetGlobal = trainSetGlobal;
                        trainingController.testSetGlobal = testSetGlobal;
                        trainingController.inputSizeGlobal = inputSizeGlobal;
                        trainingController.learningRateGlobal = learningRateGlobal;

                        System.out.println("✅ Data transferred to training controller");

                        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        stage.setScene(new Scene(view));
                        stage.setTitle("GINICAST - Training Process");
                        stage.show();

                        // ✅ AUTO-START TRAINING AFTER A SHORT DELAY
                        Platform.runLater(() -> {
                            try {
                                Thread.sleep(500); // Give UI time to render
                                trainingController.startActualTraining();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        });

                    } catch (IOException ex) {
                        ex.printStackTrace();
                        showError("Navigation Failed", "Could not open training.fxml");
                    }
                });
            }

            @Override
            protected void failed() {
                popup.close();
                Throwable ex = getException();
                if (ex != null) ex.printStackTrace();
                showError("Pipeline failed", ex != null ? ex.getMessage() : "Unknown error.");
            }
        };

        // Bind popup text to task messages
        task.messageProperty().addListener((obs, oldMsg, newMsg) -> popup.setContentText(newMsg));

        new Thread(task).start();
    }

    // ------------------------ Shared utilities ------------------------
    public void setCurrentEpoch(int epoch) {
        if (epochValueLabel != null) {
            epochValueLabel.setText(String.valueOf(epoch));
        }
    }

    private void updateSplitLabels(double trainVal) {
        int train = (int) Math.round(trainVal);
        int test = 100 - train;
        if (trainPctLabel != null) trainPctLabel.setText(pctFmt.format(train) + "%");
        if (testPctLabel != null) testPctLabel.setText(pctFmt.format(test) + "%");
    }

    /**
     * Visible default and clear on first click/focus (no auto-restore).
     */
    private void setupClearOnFirstClick(TextField field, String defaultValue) {
        field.setText(defaultValue);
        final boolean[] clearedOnce = {false};

        field.setOnMouseClicked(e -> {
            if (!clearedOnce[0]) {
                field.clear();
                clearedOnce[0] = true;
            }
        });

        field.focusedProperty().addListener((obs, was, is) -> {
            if (is && !clearedOnce[0]) {
                field.clear();
                clearedOnce[0] = true;
            }
        });
    }

    private int parseIntOrDefault(TextField tf, int def) {
        try {
            return Integer.parseInt(tf != null ? tf.getText().trim() : String.valueOf(def));
        } catch (Exception ex) {
            return def;
        }
    }

    private double parseDoubleOrDefault(TextField tf, double def) {
        try {
            return Double.parseDouble(tf != null ? tf.getText().trim() : String.valueOf(def));
        } catch (Exception ex) {
            return def;
        }
    }

    private void showError(String header, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(header);
        alert.setContentText(content);
        if (root != null && root.getScene() != null) alert.initOwner(root.getScene().getWindow());
        alert.setResizable(false);
        // showAndWait() is OK here because this method is only called from button handlers (not animation)
        alert.showAndWait();
    }

    /**
     * Switch using an Event source (used by most handlers).
     */
    private void switchTo(Event event, String fxmlName, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlName));
            Parent view = loader.load();

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(view));
            if (title != null && !title.isBlank()) stage.setTitle(title);
            stage.show();

            Platform.runLater(view::requestFocus);
        } catch (IOException e) {
            e.printStackTrace();
            showError("Navigation error", "Unable to open: " + fxmlName);
        }
    }

    /**
     * Switch using a Node ref (used from trainingprocess Esc handler & fallbacks).
     */
    private void switchToNode(Node node, String fxmlName, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlName));
            Parent view = loader.load();

            Stage stage = (Stage) node.getScene().getWindow();
            stage.setScene(new Scene(view));
            if (title != null && !title.isBlank()) stage.setTitle(title);
            stage.show();

            Platform.runLater(view::requestFocus);
        } catch (IOException e) {
            e.printStackTrace();
            // Non-blocking fallback to avoid nested loops during animations
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Navigation error");
            alert.setHeaderText("Unable to open: " + fxmlName);
            alert.setContentText(e.getMessage());
            if (node.getScene() != null) alert.initOwner(node.getScene().getWindow());
            alert.setResizable(false);
            alert.show();
        }
    }

    // -------- helper for default model name --------
    private String defaultModelName() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
        return "model-" + LocalDateTime.now().format(fmt);
    }
}

