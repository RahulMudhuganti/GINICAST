package neuralNetwork;

import java.util.Arrays;
import java.util.Random;
import java.io.Serializable;  // ✅ ADD THIS
import java.util.Arrays;
import java.util.Random;

public class NeuralNetwork implements Serializable {  // ✅ ADD implements Serializable

    private static final long serialVersionUID = 1L;
    // Initialized in constructor
	private int numberOfInputNodes;
	private double trainingRate;
	private int hiddenLayers;

	// Initialized in setup
	private double[][][] weights;
	private double[][] biases;
	private double[][] layerOutputs;

	// Initialized in trainingNN
	private double[] msreValues;

	// Initialized in testingNN
	double[] testingResults;

	public NeuralNetwork(int numberOfInputNodes, double trainingRate, int hiddenLayers) {
		this.numberOfInputNodes = numberOfInputNodes;
		this.trainingRate = trainingRate;
		this.hiddenLayers = hiddenLayers;

		setup();
	}

	private void setup() {
		// total layers includes hidden layers and output node
		int totalLayers = hiddenLayers + 1;

		weights = new double[totalLayers][][];
		biases = new double[totalLayers][];
		layerOutputs = new double[totalLayers][];

		Random rand = new Random();

		// The following sets up all the initial values in the hidden layers
		for (int layer = 0; layer < hiddenLayers; layer++) {
			int inputSize = numberOfInputNodes;
			int outputSize = numberOfInputNodes;

			weights[layer] = new double[inputSize][outputSize];
			biases[layer] = new double[outputSize];
			layerOutputs[layer] = new double[outputSize];

			for (int i = 0; i < inputSize; i++) {
				for (int j = 0; j < outputSize; j++) {
					weights[layer][i][j] = rand.nextDouble() - 0.5;
				}
			}
		}

		// The following is used to setup the output node
		weights[hiddenLayers] = new double[numberOfInputNodes][1];
		biases[hiddenLayers] = new double[1];
		layerOutputs[hiddenLayers] = new double[1];
	}

	// The following is used for training the neural network
	public void trainingNN(double[][] trainingSet) {
		msreValues = new double[trainingSet.length];

		// Each iteration is one row in the training set
		for (int row = 0; row < trainingSet.length; row++) {
			double[] sample = trainingSet[row];

			double target = sample[numberOfInputNodes];
			double[] input = Arrays.copyOf(sample, numberOfInputNodes);

			// Used for forward propogation
			double output = forward(input);

			// Calculate MSRE value
			double error = target - output;
			msreValues[row] = error * error;

			// The following is used for backpropogation
			double deltaOutput = error * sigmoidDeriv(layerOutputs[hiddenLayers][0]);

			// Calculate the backpropogation from the output node
			double[] deltas = new double[numberOfInputNodes];

			for (int i = 0; i < numberOfInputNodes; i++) {
				deltas[i] = deltaOutput * weights[hiddenLayers][i][0];
				weights[hiddenLayers][i][0] += trainingRate * deltaOutput * layerOutputs[hiddenLayers - 1][i];
			}
			biases[hiddenLayers][0] += trainingRate * deltaOutput;

			// The following travels backwards through the hidden layers
			for (int layer = hiddenLayers - 1; layer >= 0; layer--) {

				double[] currentLayerDelta = new double[numberOfInputNodes];
				double[] previousLayerOutput = (layer == 0) ? input : layerOutputs[layer - 1];

				for (int i = 0; i < numberOfInputNodes; i++) {
					double nodeError = deltas[i];
					double derivative = sigmoidDeriv(layerOutputs[layer][i]);
					currentLayerDelta[i] = nodeError * derivative;
				}

				// Updates the weights and biases
				for (int i = 0; i < numberOfInputNodes; i++) {
					for (int j = 0; j < numberOfInputNodes; j++) {
						weights[layer][i][j] += trainingRate * currentLayerDelta[j] * previousLayerOutput[i];
					}
					biases[layer][i] += trainingRate * currentLayerDelta[i];
				}

				deltas = currentLayerDelta;
			}

/*			// #####Used for checking weights during prosses#####
			if (row%(trainingSet.length/10) == 0) {
				System.out.println("Checking at " + row);
				System.out.println("Input: " + Arrays.toString(sample));
				System.out.println("Biases per layer");

				for (int layers = 0; layers < biases.length; layers++) {
					System.out.println("layer " + layers);
					System.out.println(Arrays.toString(biases[layers]));
				}
				System.out.println("Checking first layer weights");
				System.out.println(Arrays.toString(weights[0][0]));
				System.out.println("Checking last layer weights");
				System.out.println(Arrays.toString(weights[hiddenLayers][0]));
				System.out.println("Checking correct and estimate");
				System.out.println(target + " : " + output + "\n");
			}
*/
		}
	}

	// Calcualte the sigmoid value used in forward and back propogation
	private double sigmoid(double x) {
		return 1.0 / (1.0 + Math.exp(-x));
	}

	// Calculates the derivative of the sigmoid function
	// Used in backpropogation
	private double sigmoidDeriv(double x) {
		double s = sigmoid(x);
		return s * (1 - s);
	}

	// Math used for the forward propogation
	private double forward(double[] input) {
		double[] current = input;

		for (int layer = 0; layer < hiddenLayers; layer++) {
			double[] next = new double[numberOfInputNodes];

			for (int j = 0; j < numberOfInputNodes; j++) {
				double sum = biases[layer][j];

				for (int i = 0; i < numberOfInputNodes; i++) {
					sum += current[i] * weights[layer][i][j];
				}

				next[j] = sigmoid(sum);
			}

			layerOutputs[layer] = next;
			current = next;
		}

		// The following sets up the output node which is size 1
		double sum = biases[hiddenLayers][0];
		for (int i = 0; i < numberOfInputNodes; i++) {
			sum += current[i] * weights[hiddenLayers][i][0];
		}

		double output = sigmoid(sum);
		layerOutputs[hiddenLayers][0] = output;

		return output;
	}

	// Used for testing the neural network
	public void testingNN(double[][] testingSet) {
		testingResults = new double[testingSet.length];
		int counter = 0;
		for (double[] sample : testingSet) {
			double[] input = Arrays.copyOf(sample, numberOfInputNodes);
			testingResults[counter] = forward(input);
			counter++;
		}
	}

	// Used for getting MSRE Values
	public double[] getMSREValues() {
		return msreValues;
	}
    public double predict(double[] input) {
        return forward(input);
    }

    // Used for getting tested Results
	public double[] getTestedResults() {
		return testingResults;
	}

	// Used for testing neural network
	public static void main(String[] args) {
		NeuralNetwork nn = new NeuralNetwork(3, 0.2, 3);
		double[][] trainingSet = {{0.4, 0.5, 0.7, 0.5},
								  {0.3, 0.7, 0.2, 0.7},
								  {0.6, 0.6, 0.5, 0.4},
								  {0.2, 0.4, 0.6, 0.3},
								  {0.7, 0.8, 0.5, 0.8}};
		double[][] testingSet = {{0.6, 0.4, 0.3, 0.5},
								 {0.5, 0.5, 0.2, 0.4},
								 {0.7, 0.6, 0.3, 0.6}};

		nn.trainingNN(trainingSet);
		System.out.println(Arrays.toString(nn.getMSREValues()));
		nn.testingNN(testingSet);
	}
}