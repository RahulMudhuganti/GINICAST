package neuralNetwork;

import java.io.*;
import java.util.*;

public class NormalizedDataCSVReader {

	private String filePath;
	private double[][] normalizedDataSet;
	private boolean readIn = false;

	public NormalizedDataCSVReader(String filePath) {
		this.filePath = filePath;
		setup();
	}

	private void setup() {
		List<double[]> rows = new ArrayList<>();

		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {

			String line;
			br.readLine();

			while ((line = br.readLine()) != null) {
				String[] parts = line.split(",");

				double[] row = new double[parts.length];

				for (int i = 0; i < parts.length; i++) {
					row[i] = Double.parseDouble(parts[i]);
				}

				rows.add(row);
			}

		}
		catch (IOException e) {
			e.printStackTrace();
		}

		// Converts ArrayList to double[][]
		normalizedDataSet = new double[rows.size()][];
		for (int i = 0; i < rows.size(); i++) {
			normalizedDataSet[i] = rows.get(i);
		}
		readIn = true;
	}

	public double[][] getNormalizedDataSet() {
		if (readIn)
			return normalizedDataSet;
		return null;
	}
}