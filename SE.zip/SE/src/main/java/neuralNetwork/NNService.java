package neuralNetwork;

import java.util.Arrays;

/**
 * NNService
 * ----------
 * Wraps your custom neural network classes and returns results in a simple structure.
 */
public class NNService {

    public static class Result {
        public double[][] train;
        public double[][] test;
        public double[] predictions;

        public Result(double[][] train, double[][] test, double[] predictions) {
            this.train = train;
            this.test = test;
            this.predictions = predictions;
        }
        public double getAccuracy() {
            if (predictions == null || test == null) return 0.0;

            int correct = 0;
            int n = predictions.length;

            for (int i = 0; i < n; i++) {
                double actual = test[i][test[i].length - 1];

                // Convert continuous prediction to class (0/1)
                int predClass = predictions[i] >= 0.5 ? 1 : 0;
                int actualClass = actual >= 0.5 ? 1 : 0;

                if (predClass == actualClass) correct++;
            }

            return (double) correct / n;
        }

        public double getMSE() {
            if (predictions == null || test == null) return 0.0;

            double total = 0;
            int n = predictions.length;

            for (int i = 0; i < n; i++) {
                double actual = test[i][test[i].length - 1];
                double diff = predictions[i] - actual;
                total += diff * diff;
            }

            return total / n;
        }

        public double getRMSE() {
            return Math.sqrt(getMSE());
        }

        public double[] getPredictions() {
            return predictions;
        }
    }

    /**
     * Run neural network training + testing pipeline.
     *
     * @param normalizedData Full dataset (normalized), last column = target.
     * @param numInputs      Number of input columns
     * @param lr             Learning rate
     * @param hiddenLayers   Number of hidden layers
     * @param trainSplit     0.0 – 1.0 (e.g. 0.7)
     * @return NN results
     */
    public static Result run(double[][] normalizedData,
                             int numInputs,
                             double lr,
                             int hiddenLayers,
                             double trainSplit) throws Exception {

        if (normalizedData == null || normalizedData.length == 0)
            throw new Exception("Normalized dataset is empty.");

        // 1) Split dataset
        TestingTrainingSet tts = new TestingTrainingSet(normalizedData, trainSplit);
        double[][] train = tts.getTrainingSet();
        double[][] test = tts.getTestingSet();

        if (train.length == 0 || test.length == 0)
            throw new Exception("Training/testing split produced empty sets.");

        // 2) Train NN
        NeuralNetwork nn = new NeuralNetwork(numInputs, lr, hiddenLayers);
        nn.trainingNN(train);

        // 3) Predict
        nn.testingNN(test);
        double[] preds = nn.getTestedResults();

        if (preds == null)
            throw new Exception("Neural network produced null predictions.");
        if (preds.length != test.length)
            throw new Exception("Mismatch in prediction length.");

        return new Result(train, test, preds);
    }
}
