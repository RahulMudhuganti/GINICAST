package neuralNetwork;

import java.util.*;

public class TestingTrainingSet {

	private double[][] trainingDataSet;
	private double[][] testingDataSet;

	public TestingTrainingSet (double[][] normalizedData, double trainingPercentage) {

		// Convert double[][] to ArrayList
		List<double[]> dataList = new ArrayList<>();
		for (double[] row : normalizedData) {
			dataList.add(row);
		}

		// Using collection to randomize the rows
		Collections.shuffle(dataList);

		// Calculate the training size
		int dataLength = normalizedData.length;
		int trainingSize = (int) Math.floor(dataLength * trainingPercentage);

		// Initialize sizes of training and testing sets
		trainingDataSet = new double[trainingSize][];
		testingDataSet = new double[dataLength - trainingSize][];

		// Insert shuffled data into training and testing sets
		for (int i = 0; i < dataLength; i++) {
			if (i < trainingSize)
				trainingDataSet[i] = dataList.get(i);
			else
				testingDataSet[i - trainingSize] = dataList.get(i);
		}
	}

	public double[][] getTestingSet() {
		return testingDataSet;
	}

	public double[][] getTrainingSet() {
		return trainingDataSet;
	}

	public static void main(String args[]) {
		double[][] normalizedData = {{0.1,0.6},
									 {0.2,0.7},
									 {0.3,0.8},
									 {0.4,0.9},
									 {0.5,1.0}};
		double trainingPercentage = 0.6;

		TestingTrainingSet tts = new TestingTrainingSet(normalizedData, trainingPercentage);

		System.out.println("Training Set: " + Arrays.deepToString(tts.getTrainingSet()));
		System.out.println("Testing Set: " + Arrays.deepToString(tts.getTestingSet()));
	}
}