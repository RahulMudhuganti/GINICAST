package neuralNetwork;

public class Main {
	public static void main(String[] args) {

		// Used for reading in data
		System.out.println("Reading in normalized data from file");
		NormalizedDataCSVReader ndr = new NormalizedDataCSVReader("normalizedData.csv");
		double[][] normalizedData = ndr.getNormalizedDataSet();
		if (normalizedData == null) {
			System.out.println("Error occured when reading in data");
			return;
		}
		System.out.println("Successfully read in normalized data\n");

		// Used for creating training and testing sets
		System.out.println("Creating testing training set 70/30 split\n");
		double trainingPercentage = 0.7;
		TestingTrainingSet tts = new TestingTrainingSet(normalizedData, trainingPercentage);
		double[][] trainingSet = tts.getTrainingSet();
		double[][] testingSet = tts.getTestingSet();

		// Used for neural network
		System.out.println("Creating neural network");
		NeuralNetwork nn = new NeuralNetwork(9, 0.2, 5);
		System.out.println("Training neural network");
		nn.trainingNN(trainingSet);
		double[] msreValue = nn.getMSREValues();
/*		System.out.println("# of MSRE values and sample of values");
		System.out.println(msreValue.length);
		for (int i = 0; i < msreValue.length; i += (int)msreValue.length/20)
			System.out.println(msreValue[i]);
*/

		System.out.println("Testing neural network");
		nn.testingNN(testingSet);

		double[] testingResults = nn.getTestedResults();
/*		for (int i = 0; i < testingResults.length; i += testingResults.length/10) {
			System.out.println("Real Value : Estimated Value");
			System.out.println(testingSet[i][9] + " : " + testingResults[i]);
		}
*/
	}
}