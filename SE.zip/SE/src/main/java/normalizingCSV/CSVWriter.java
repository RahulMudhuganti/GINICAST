package normalizingCSV;

import java.io.*;

// CSVWriter is designed to write a csv file from tuples and a string header
public class CSVWriter {

	private boolean wrote = true;

	// Constructor for writing normalized file
	public CSVWriter(String filePath, String[] header, double[][] values) {
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {

			// Insert Header
			for (int i = 0; i < header.length; i++) {
				writer.write(header[i]);
				if (i < header.length - 1)
					writer.write(",");
			}
			writer.newLine();

			// Insert data
			for (double[] row : values) {
				for (int j = 0; j < row.length; j++) {
					// Format to 5 decimal places can make adjustable but fixed write now
					writer.write(String.format("%.5f", row[j]));
					if (j < row.length - 1)
						writer.write(",");
				}
				writer.newLine();
			}

		}

		// Error in writing
		catch (IOException e) {
			wrote = false;
			return;
		}
	}

	// Used to determine if file was successfully written
	public boolean getWrote() {
		return wrote;
	}
}