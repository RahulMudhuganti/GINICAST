package normalizingCSV;

import java.io.*;
import java.util.*;

// CSVReader is designed to take a file path of type .csv
public class CSVReader {

	// Stored variables from reading file
	private List<String[]> rows;
	private Boolean isEmpty;
	private String[] header;
	private int numberRows;
	private int numberColumns;

	// Class constructor for reading file and getting initial data values
	public CSVReader(String filePath) {
		try {
			// Read in file
			rows = new ArrayList<>();
			try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
				String row;
				while ( (row = br.readLine()) != null) {
					String[] values = row.split(",", -1);
					rows.add(values);
				}
			}

			// Empty file
			if (rows.isEmpty()) {
				isEmpty = true;
				return;
			}
			isEmpty = false;

			// Store column names as header
			header = rows.get(0);
			rows.remove(0);
			// Get number of columns and rows
			numberColumns = header.length;
			numberRows = rows.size();

			return;
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	} // End constructor

	// Allows other classes to see if file selected was empty
	// or doesn't have any data points
	public boolean checkFile() {
		if (isEmpty)
			return false;
		if (numberRows == 0 || numberColumns == 0)
			return false;
		return true;
	}

	// Return number of datapoints
	public int getNumberRows() {
		return numberRows;
	}

	// Return number of columns
	public int getNumberColumns() {
		return numberColumns;
	}

	// Return List of all datapoints
	public List<String[]> getRows() {
		return rows;
	}

	// Return header description of each column
	public String[] getHeader() {
		return header;
	}

	// Used for testing class
	public static void main(String[] args) {

	String filePath = "housing.csv"; // Testing .csv file
	CSVReader read = new CSVReader(filePath);
	System.out.println(read.checkFile() ? "Holds data" : "No data");
	System.out.println(read.getNumberRows());
	System.out.println(read.getNumberColumns());
	}
}