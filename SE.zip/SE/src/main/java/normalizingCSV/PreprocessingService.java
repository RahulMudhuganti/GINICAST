package normalizingCSV;

import java.util.List;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

import java.util.List;
import java.util.ArrayList;


/**
 * PreprocessingService
 * ---------------------
 * Runs your full preprocessing pipeline:
 *  1) Read CSV
 *  2) Remove incomplete/invalid rows
 *  3) Remove outliers
 *  4) Normalize valid rows
 * Returns: double[][] normalized dataset
 */
public class PreprocessingService {

    /**
     * @param filePath path to CSV
     * @param types    column types (string, double, boolean, etc.)
     * @param k        not used in this Normalizer version (kept for compatibility)
     * @return normalized dataset
     */

    public static double[][] preprocess(String filePath, String[] types, int k) throws Exception {

        // 1) Read CSV
        CSVReader csv = new CSVReader(filePath);

        if (!csv.checkFile()) {
            throw new Exception("CSV file is empty or invalid!");
        }

        List<String[]> rows = csv.getRows();
        int numRows = csv.getNumberRows();
        int numCols = csv.getNumberColumns();

        if (types.length != numCols) {
            throw new Exception("Column types length does not match CSV header count!");
        }

        // 2) Remove rows with missing values & too many '?'
        RemoveRows removeRows = new RemoveRows(rows, numRows, numCols);
        if (removeRows.isEmpty()) {
            throw new Exception("All rows removed after filtering invalid rows.");
        }

        rows = removeRows.getRows();
        numRows = rows.size();

        // 3) Remove outliers
        Outliers out = new Outliers(rows, types, numRows);
        if (out.isEmpty()) {
            throw new Exception("All rows removed after outlier detection.");
        }

        rows = out.getRows();
        numRows = rows.size();

        // 4) Normalize using your updated Normalizer constructor
        Normalizer norm = new Normalizer(rows, types);

        // IMPORTANT FIX: Your new Normalizer uses getRows(), not getNormalizedData()
        double[][] normalized = norm.getRows();

        if (normalized == null || normalized.length == 0) {
            throw new Exception("Normalization failed. Empty dataset returned.");
        }

        return normalized;
    }
    public static double[][] loadAndCleanCSV(File file, int expectedCols) {

        List<double[]> cleaned = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {

            String line;
            br.readLine(); // skip header

            while ((line = br.readLine()) != null) {

                String[] parts = line.split(",");

                // If row doesn't have required number of columns → skip it
                if (parts.length < expectedCols) {
                    System.out.println("Skipping row (not enough values): " + line);
                    continue;
                }

                double[] row = new double[expectedCols];

                boolean skipRow = false;

                for (int i = 0; i < expectedCols; i++) {
                    String val = parts[i].trim();

                    if (val.isEmpty()) {
                        skipRow = true;
                        break;
                    }

                    try {
                        row[i] = Double.parseDouble(val);
                    } catch (Exception ex) {
                        skipRow = true;
                        break;
                    }
                }

                if (!skipRow) cleaned.add(row);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return cleaned.toArray(new double[0][]);
    }

}
