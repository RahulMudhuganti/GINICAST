package normalizingCSV;

import java.util.*;

// Takes in CSV and removes tuples that are to short
// Or tuples that have more than 25% unknown variables
public class RemoveRows {

	// Stored variables for removing rows
	private List<String[]> rows;
	private boolean isEmpty = false;
	private int rowsRemovedShort = 0;
	private int rowsRemovedUnknowns = 0;

	// Constructor that takes in ArrayList of strings
	// And returns same format but with less data points if not standard values
	public RemoveRows(List<String[]> rawData, int numberRows, int numberColumns) {

		rows = rawData;
		int row = 0;

		// Removes rows with length less than number of columns
		while (row < numberRows) {
			if (rows.get(row).length < numberColumns) {
				rows.remove(row);
				rowsRemovedShort++;
				numberRows--;
				continue;
			}
			row++;
		}
		if (numberRows == 0) {
			isEmpty = true;
			return;
		}

		row = 0;

		// Removes rows with more than 25% unknown values
		while (row < numberRows) {
			int numberUnknowns = 0;
			for (int i = 0; i < numberColumns; i++) {
				String value = rows.get(row)[i];
				if (value.equals('?') || value.isEmpty())
					numberUnknowns++;
			}
			if ((double)numberUnknowns / (double)numberColumns > 0.25) {
				rows.remove(row);
				rowsRemovedUnknowns++;
				numberRows--;
				continue;
			}
			row++;
		}
		if (numberRows == 0) {
			isEmpty = true;
			return;
		}
	}

	// Used to get number of rows removed due to it being shorter than number of headers
	public int getRowsRemovedShort() {
		return rowsRemovedShort;
	}

	// Used to get number of rows removed due to it having more than 25% unknown values
	public int getRowsRemovedUnknowns() {
		return rowsRemovedUnknowns;
	}

	// Used to get updated data used
	public List<String[]> getRows() {
		return rows;
	}

	// Used to see if all tuples were removed from data
	public boolean isEmpty() {
		return isEmpty;
	}

	// Used for testing class
	public static void main(String[] args) {
		List<String[]> test = new ArrayList<>();
		test.add(new String[]{"Alissa","25","67","4.0", "false"});
		test.add(new String[]{"Bradley","28","69","4.0", "false"});
		test.add(new String[]{"33","12","true"});
		test.add(new String[]{"Sir","55","", "", "true"});
		test.add(new String[]{"Mom","52","65","", "true"});

		RemoveRows removeRows = new RemoveRows(test, 5, 5);
		if (removeRows.isEmpty()) {
			System.out.println("Their is no more data points available");
			return;
		}

		System.out.println("\nRowsRemovedShort " + removeRows.getRowsRemovedShort());
		System.out.println("\nRowsRemovedUnknown " + removeRows.getRowsRemovedUnknowns());

	}
}