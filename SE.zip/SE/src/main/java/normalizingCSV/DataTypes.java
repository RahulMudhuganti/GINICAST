package normalizingCSV;

import java.util.*;

// Converts variables from CSV into datapoints
// used in nueral network
public class DataTypes {

	// Stored variables from converting CSV
	private List<String[]> rows;
	private String[] dataTypes;

	private int numberInt = 0;
	private int numberDbl = 0;
	private int numberBool = 0;
	private int numberString = 0;

	// Constructor that takes in ArrayList of strings
	// and calculates data format
	public DataTypes(List<String[]> rawData, int numberRows, int numberColumns) {

		dataTypes = new String[numberColumns];
		rows = rawData;

		// Used to determine datatype of each column
		for (int i = 0; i < numberColumns; i++) {

			if (isBoolean(i, numberRows)) {
				dataTypes[i] = "boolean";
				numberBool++;
			}
			else if (isInteger(i, numberRows)) {
				dataTypes[i] = "integer";
				numberInt++;
			}
			else if (isDouble(i, numberRows)) {
				dataTypes[i] = "double";
				numberDbl++;
			}
			else {
				dataTypes[i] = "string";
				numberString++;
			}
		}
	}

	// Checks if type is Boolean
	private boolean isBoolean(int column, int numberRows) {
		for (int i = 0; i < numberRows; i++) {
			String value = rows.get(i)[column].toLowerCase();
			if (value.equals('?') || value.isEmpty()) {
				rows.get(i)[column] = "";
				continue;
			}
			if (!value.equals("true") && !value.equals("false")) {
				return false;
			}
		}
		return true;
	}

	// Checks if type is Integer
	private boolean isInteger(int column, int numberRows) {
		for (int i = 0; i < numberRows; i++) {
			String value = rows.get(i)[column];
			if (value.equals('?') || value.isEmpty()) {
				rows.get(i)[column] = "";
				continue;
			}
			try {
				Integer.parseInt(value);
			}
			catch (NumberFormatException e) {
				return false;
			}
		}
		return true;
	}

	// Checks if type is Double
	private boolean isDouble(int column, int numberRows) {
		for (int i = 0; i < numberRows; i++) {
			String value = rows.get(i)[column];
			if (value.equals('?') || value.isEmpty()) {
				rows.get(i)[column] = "";
				continue;
			}
			try {
				Double.parseDouble(value);
			}
			catch (NumberFormatException e) {
				return false;
			}
		}
		return true;
	}

	// Used to get the dataTypes of each column
	public String[] getDataTypes() {
		return dataTypes;
	}

	// Used to update data used
	public List<String[]> getRows() {
		return rows;
	}

	public String getNumberOfDataTypes() {
		String results = "Strings-" + numberString + "\t";
		results += "Boolean-" + numberBool + "\t";
		results += "Integer-" + numberInt + "\t";
		results += "Double-" + numberDbl + "\n";
		return results;
	}

	// Used for testing class
	public static void main(String[] args) {
		List<String[]> test = new ArrayList<>();
		test.add(new String[]{"Alissa","25","67","4.0", "false"});
		test.add(new String[]{"Bradley","28","69","4.0", "false"});
		test.add(new String[]{"33","12","true"});
		test.add(new String[]{"Sir","55","73", "", "true"});
		test.add(new String[]{"Mom","52","65","", "true"});

		DataTypes dataTypes = new DataTypes(test, 5, 5);
		String[] types = dataTypes.getDataTypes();
		System.out.println("Datatypes per column.");
		for (int i = 0; i < types.length; i++)
			System.out.print(types[i] + ", ");
	}
}