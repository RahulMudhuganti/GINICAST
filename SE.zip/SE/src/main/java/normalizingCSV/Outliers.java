package normalizingCSV;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

// Outliers uses the statistical analysis techniques
// To find inconsistant value points and remove them
public class Outliers {

	private List<String[]> rows;
	private String[] dataTypes;
	private int numberRows;
	private boolean isEmpty = false;
	private int outliersRemoved = 0;

	public Outliers(List<String[]> rows, String[] dataTypes, int numberRows) {
		this.rows = rows;
		this.dataTypes = dataTypes;
		this.numberRows = numberRows;

		// Loop through each column
		for (int i = 0; i < dataTypes.length; i++) {
			String type = dataTypes[i];

			// Skip columns of type boolean or string
			if (type.equals("boolean") || type.equals("string"))
				continue;

			// Used for finding all unique values within a column
			List<Double> values = new ArrayList<>();
			for (int j = 0; j < numberRows; j++) {
				String val = rows.get(j)[i].trim();
				if (val.isEmpty() || val.equals("?"))
					continue;
				try {
					values.add(Double.parseDouble(val));
				}
				catch (NumberFormatException e)
				{}
			}

			// Not enough data to calculate outliers
			if (values.size() < 5)
				continue;

			Collections.sort(values);

			double q1 = getPercentile(values, 25);
			double q3 = getPercentile(values, 75);
			double dispersion = q3 - q1;

			double lowerBound = q1 - 1.5 * dispersion;
			double upperBound = q3 + 1.5 * dispersion;

			// Remove rows where this column’s value is outside [lowerBound, upperBound]
			int row = 0;
			while (row < numberRows) {
				String val = rows.get(row)[i].trim();
				if (val.isEmpty() || val.equals("?")) {
					row++;
					continue;
				}
				try {
					double value = Double.parseDouble(val);
					if (value < lowerBound || value > upperBound) {
						rows.remove(row);
						outliersRemoved++;
						numberRows--;
						continue;
					}
				}
				catch (NumberFormatException e) {
				}
				row++;
			}
			if (numberRows == 0) {
				isEmpty = true;
				return;
			}
		}
	}

	// Used to calculate percentiles from sorted values
	private double getPercentile(List<Double> sortedValues, double percentile) {
		double index = percentile / 100.0 * (sortedValues.size() - 1);
		int lowerIndex = (int) Math.floor(index);
		int upperIndex = (int) Math.ceil(index);

		if (lowerIndex == upperIndex)
			return sortedValues.get(lowerIndex);

		double weight = index - lowerIndex;
		return sortedValues.get(lowerIndex) * (1 - weight) + sortedValues.get(upperIndex) * weight;
	}

	// Used to see if all tuples were removed from data
	public boolean isEmpty() {
		return isEmpty;
	}

	// Used to see number of rows removed from outliers
	public int getRowsRemovedOutliers() {
		return outliersRemoved;
	}

	// Used to get updated data
	public List<String[]> getRows() {
		return rows;
	}

	// Used for testing class
	public static void main(String[] args) {
		// Skipped testing. Tested with actual csv file.
	}
}