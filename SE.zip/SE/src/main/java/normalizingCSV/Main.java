package normalizingCSV;

public class Main {

	public static void main(String[] args) {

		// Everything needed to read file
		String filePath = "housing.csv";
		System.out.println("-Reading in file - " + filePath);
		CSVReader reader = new CSVReader(filePath);
		if (!reader.checkFile()) {
			System.out.println("No data recorded");
			return;
		}
		System.out.println("Data read in successfully");
		int rows = reader.getNumberRows();
		int columns = reader.getNumberColumns();
		String[] header = reader.getHeader();
		System.out.println("Number of categories - " + columns);
		System.out.println("Number of datapoints - " + rows);


		// Everything needed to remove tuples with to many unknowns/short length
		System.out.println("-Removing ensificient datapoints");
		RemoveRows removeRows = new RemoveRows(reader.getRows(),
											   rows,
											   columns);
		if (removeRows.isEmpty()) {
			System.out.println("No data available");
			return;
		}
		int rowsRemovedShort = removeRows.getRowsRemovedShort();
		System.out.println("Rows removed from ensificient data - " + rowsRemovedShort);
		int rowsRemovedUnknowns = removeRows.getRowsRemovedUnknowns();
		System.out.println("Rows removed from having more than 25% unknowns - " + rowsRemovedUnknowns);
		rows = rows - rowsRemovedShort - rowsRemovedUnknowns;
		System.out.println("New number of datapoints - " + rows);


		// Everything needed to assign datatypes to each column
		System.out.println("-Assigning perameter types to columns");
		DataTypes dataTypes = new DataTypes(removeRows.getRows(),
											rows,
											columns);
		String[] types = dataTypes.getDataTypes();
		System.out.print("Number of different datatypes - " + dataTypes.getNumberOfDataTypes());


		// Everything needed to remove outliers
		System.out.println("-Removing outliers");
		Outliers outlier = new Outliers(dataTypes.getRows(),
										types,
										rows);
		if (outlier.isEmpty()) {
			System.out.println("No data available");
			return;
		}
		int rowsRemovedOutliers = outlier.getRowsRemovedOutliers();
		System.out.println("Number of outleirs removed - " + rowsRemovedOutliers);
		rows = rows - rowsRemovedOutliers;
		System.out.println("New number of datapoints - " + rows);


		// Everything needed to clean data
		System.out.println("-Replacing missing values");
		int kValue = 3;
		Cleaning cleaner = new Cleaning(outlier.getRows(),
										reader.getHeader(),
										types,
										kValue);
		int replacedValues = cleaner.getTotalReplacedValues();
		System.out.println("Unknown values replaced - " + replacedValues);


		// Everything needed to normalize data
		System.out.println("-Normalizing data");
		Normalizer normalizer = new Normalizer(cleaner.getRows(), types);
		double[][] normalized = normalizer.getRows();


		// Everything needed to write data to file
		System.out.println("-Writing normalized data");
		CSVWriter writer = new CSVWriter("normalizedData.csv", header, normalized);
		if (!writer.getWrote()) {
			System.out.println("Failed to write file");
			return;
		}
		System.out.println("Successfully wrote file");
	}
}