package normalizingCSV;

import java.util.*;

// Normalizer converts all values into a 0–1 numeric scale.
// It supports: int, double, boolean, and limited string encoding.
public class Normalizer {

    private List<String[]> rows;
    private String[] types;
    private int numRows;
    private int numCols;

    private double[] mins;
    private double[] maxs;

    // For string encoding
    private String[][] uniqueValues;
    private double[][] uniqueEncodings;

    // Constructor
    public Normalizer(List<String[]> rows, String[] types) {
        this.rows = rows;
        this.types = types;

        this.numRows = rows.size();
        this.numCols = types.length;

        this.mins = new double[numCols];
        this.maxs = new double[numCols];
        this.uniqueValues = new String[numCols][];
        this.uniqueEncodings = new double[numCols][];

        computeMinMax();
        buildEncoders();
    }

    // ------------------------------------------------------------
    // STEP 1: Compute min/max for each numeric/boolean column
    // ------------------------------------------------------------
    private void computeMinMax() {
        Arrays.fill(mins, Double.POSITIVE_INFINITY);
        Arrays.fill(maxs, Double.NEGATIVE_INFINITY);

        for (int col = 0; col < numCols; col++) {
            String type = types[col].toLowerCase();

            if (type.equals("int") || type.equals("double") || type.equals("boolean")) {
                for (String[] row : rows) {
                    String raw = row[col];
                    if (raw == null || raw.trim().isEmpty()) continue;

                    double value;
                    try {
                        if (type.equals("boolean"))
                            value = Boolean.parseBoolean(raw) ? 1.0 : 0.0;
                        else
                            value = Double.parseDouble(raw);
                    } catch (NumberFormatException e) {
                        continue;
                    }

                    mins[col] = Math.min(mins[col], value);
                    maxs[col] = Math.max(maxs[col], value);
                }
            }
        }
    }

    // ------------------------------------------------------------
    // STEP 2: Identify string columns with low uniqueness (<5%)
    //         and assign encoding 0–1 based on order found.
    // ------------------------------------------------------------
    private void buildEncoders() {
        for (int col = 0; col < numCols; col++) {

            if (!types[col].equalsIgnoreCase("string"))
                continue;

            List<String> unique = new ArrayList<>();

            for (String[] row : rows) {
                String val = row[col];
                if (val != null && !val.trim().isEmpty() && !unique.contains(val)) {
                    unique.add(val);
                }
            }

            double uniquenessRatio = (double) unique.size() / numRows;

            // Only encode if less than 5% unique values
            if (uniquenessRatio <= 0.05 && !unique.isEmpty()) {

                int count = unique.size();
                uniqueValues[col] = new String[count];
                uniqueEncodings[col] = new double[count];

                for (int i = 0; i < count; i++) {
                    uniqueValues[col][i] = unique.get(i);
                    uniqueEncodings[col][i] = (count > 1) ? (double) i / (count - 1) : 0.0;
                }
            }
        }
    }

    // ------------------------------------------------------------
    // STEP 3: Normalize entire dataset
    // ------------------------------------------------------------
    public double[][] getRows() {
        double[][] normalized = new double[numRows][numCols];

        for (int row = 0; row < numRows; row++) {
            String[] rawRow = rows.get(row);

            for (int col = 0; col < numCols; col++) {
                String type = types[col].toLowerCase();
                String raw = rawRow[col];

                double value = 0.0;

                switch (type) {
                    case "int":
                    case "double":
                    case "boolean":
                        value = safeToDouble(raw, type);

                        double min = mins[col];
                        double max = maxs[col];

                        if (max != min &&
                                min != Double.POSITIVE_INFINITY &&
                                max != Double.NEGATIVE_INFINITY)
                        {
                            value = (value - min) / (max - min);
                        } else {
                            value = 0.0;
                        }
                        break;

                    case "string":
                        if (uniqueValues[col] != null)
                            value = encode(raw, uniqueValues[col], uniqueEncodings[col]);
                        else
                            value = 0.0;
                        break;

                    default:
                        value = 0.0;
                }

                normalized[row][col] = value;
            }
        }

        return normalized;
    }

    // ------------------------------------------------------------
    // Helper methods
    // ------------------------------------------------------------
    private double safeToDouble(String val, String type) {
        if (val == null || val.trim().isEmpty())
            return 0.0;

        try {
            if (type.equals("boolean"))
                return Boolean.parseBoolean(val) ? 1.0 : 0.0;

            return Double.parseDouble(val);
        }
        catch (NumberFormatException e) {
            return 0.0;
        }
    }

    private double encode(String value, String[] keys, double[] codes) {
        if (value == null)
            return 0.0;

        for (int i = 0; i < keys.length; i++) {
            if (value.equals(keys[i]))
                return codes[i];
        }
        return 0.0;
    }

    // ------------------------------------------------------------
    // Testing (optional)
    // ------------------------------------------------------------
    public static void main(String[] args) {
        String[] types = {"String", "int", "double", "double", "Boolean"};

        List<String[]> data = new ArrayList<>();
        data.add(new String[]{"Alissa","25","167","4.0", "false"});
        data.add(new String[]{"Bradley","29","69","4.0", "false"});
        data.add(new String[]{"Sir","55","73","3.2", "true"});
        data.add(new String[]{"Mom","52","48","3.5", "true"});

        Normalizer norm = new Normalizer(data, types);

        double[][] out = norm.getRows();
        for (double[] row : out) {
            for (double v : row) {
                System.out.printf("%.5f, ", v);
            }
            System.out.println();
        }
    }
}
