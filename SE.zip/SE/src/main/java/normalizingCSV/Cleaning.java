package normalizingCSV;

import java.util.*;

// Take CSV values and replaces missing rows using KNN and Euclidean distance formula
public class Cleaning {
	private List<String[]> rows;
	private String[] headers;
	private String[] types;
	private int k;
	private int totalReplacedValues = 0;

	// Constructor for initializing rows
	public Cleaning(List<String[]> rows, String[] headers, String[] types, int k) {
		this.rows = rows;
		this.headers = headers;
		this.types = types;
		this.k = Math.max(1, k);

		for (int i = 0; i < rows.size(); i++) {
			for (int j = 0; j < headers.length; j++) {
				if (isMissing(rows.get(i)[j])) {
					String result = imputeCellUsingKNN(i, j);
					totalReplacedValues++;
				}
			}
		}
	}

	// Given missing rows cell, used to figure out which values
	// to store in its place using KNN
	public String imputeCellUsingKNN(int targetRow, int targetCol) {
		if (targetRow < 0 || targetRow >= rows.size()) return null;
		if (targetCol < 0 || targetCol >= headers.length) return null;

		String current = rows.get(targetRow)[targetCol];
		if (!isMissing(current)) {
			return current;
		}

		class Neighbor {
			int rowIdx;
			double distance;
			Neighbor(int r, double d) {
				rowIdx = r;
				distance = d;
			}
		}

		List<Neighbor> neighbors = new ArrayList<>();

		for (int i = 0; i < rows.size(); i++) {
			if (i == targetRow)
				continue;
			String[] other = rows.get(i);
			String[] target = rows.get(targetRow);

			double sumSq = 0.0;
			int featuresUsed = 0;

			for (int c = 0; c < types.length; c++) {
				String typ = types[c].toLowerCase();
				if (!(typ.equals("int") || typ.equals("double") || typ.equals("boolean")))
					continue;

				String a = target[c];
				String b = other[c];

				if (isMissing(a) || isMissing(b))
					continue;

				try {
					double da;
					double db;
					if (typ.equals("boolean")) {
						da = Boolean.parseBoolean(a) ? 1.0 : 0.0;
						db = Boolean.parseBoolean(b) ? 1.0 : 0.0;
					}
					else {
						da = Double.parseDouble(a);
						db = Double.parseDouble(b);
					}
					double diff = da - db;
					sumSq += diff * diff;
					featuresUsed++;
				}
				catch (NumberFormatException ex) {
				}
			}

			if (featuresUsed > 0) {
				double dist = Math.sqrt(sumSq / featuresUsed);
				neighbors.add(new Neighbor(i, dist));
			}
		}

		if (neighbors.isEmpty()) {
			return null;
		}

		Collections.sort(neighbors, new Comparator<Neighbor>() {
			public int compare(Neighbor a, Neighbor b) {
				return Double.compare(a.distance, b.distance);
			}
		});

		int use = Math.min(k, neighbors.size());
		List<Integer> topIdx = new ArrayList<>();
		for (int i = 0; i < use; i++)
			topIdx.add(neighbors.get(i).rowIdx);

		List<String> neighborVals = new ArrayList<>();
		for (int idx : topIdx) {
			String v = rows.get(idx)[targetCol];
			if (!isMissing(v))
				neighborVals.add(v);
		}

		if (neighborVals.isEmpty()) {
			return null;
		}

		String colType = types[targetCol].toLowerCase();
		String imputed = null;
		switch (colType) {
			case "int": {
				double sum = 0.0;
				int count = 0;
				for (String v : neighborVals) {
					try {
						sum += Double.parseDouble(v);
						count++;
					}
					catch (NumberFormatException ex) {

					}
				}
				if (count > 0) {
					int rounded = (int) Math.round(sum / count);
					imputed = Integer.toString(rounded);
				}
				break;
			}
			case "double": {
				double sum = 0.0;
				int count = 0;
				for (String v : neighborVals) {
					try {
						sum += Double.parseDouble(v);
						count++;
					}
					catch (NumberFormatException ex) {

					}
				}
				if (count > 0) {
					double avg = sum / count;
					imputed = String.format("%.3f", avg);
				}
				break;
			}
			case "boolean": {
				int trueCount = 0;
				int count = 0;
				for (String v : neighborVals) {
					if (Boolean.parseBoolean(v))
						trueCount++;
					count++;
				}
				if (count > 0) {
					boolean majority = trueCount >= (count - trueCount);
					imputed = Boolean.toString(majority);
				}
				break;
			}
			default: {
				String mode = neighborVals.get(0);
				int modeCount = 0;
				for (String candidate : neighborVals) {
					int ccount = 0;
					for (String v : neighborVals)
						if (candidate.equals(v))
							ccount++;
					if (ccount > modeCount) {
						modeCount = ccount;
						mode = candidate;
					}
				}
				imputed = mode;
			}
		}

		if (imputed != null) {
			rows.get(targetRow)[targetCol] = imputed;
		}

		return imputed;
	}

	// Used for finding missing values
	private boolean isMissing(String s) {
		return s == null || s.trim().isEmpty();
	}

	// Used to update rows used
	public List<String[]> getRows() {
		return rows;
	}

	public int getTotalReplacedValues() {
		return totalReplacedValues;
	}

	// Used for testing class
	public static void main(String[] args) {
		String[] headers = {"Name", "Age", "Height", "GPA", "Graduated"};
		String[] types   = {"String", "int", "double", "double", "Boolean"};

		List<String[]> test = new ArrayList<>();
		test.add(new String[]{"Alissa","25","67","4.0", "false"});
		test.add(new String[]{"Bradley","28","69","3.72", "false"});
		test.add(new String[]{"Sir","55","73", "", "true"});
		test.add(new String[]{"Mom","","65","3.5", "true"});

		Cleaning cleaner = new Cleaning(test, headers, types, 2);

		List<String[]> cleaned = cleaner.getRows();
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 5; j++) {
				System.out.print(cleaned.get(i)[j] + ", ");
			}
			System.out.println();
		}
		System.out.println("Total values replaced: " + cleaner.getTotalReplacedValues());
	}
}